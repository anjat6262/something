import { IntroAnimation } from './components/IntroAnimation';
import { BirthdayCakePopup } from './components/BirthdayCakePopup';
import { PageNavigation } from './components/PageNavigation';
import { HeroPage } from './components/pages/HeroPage';
import { LetterPage } from './components/pages/LetterPage';
import { DigitalScrapbookPage } from './components/pages/DigitalScrapbookPage';
import { MagicMirrorPage } from './components/pages/MagicMirrorPage';
import { MiniGamesPage } from './components/pages/MiniGamesPage';
import { WishesPage } from './components/pages/WishesPage';
import { GoodbyePage } from './components/pages/GoodbyePage';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [showCakePopup, setShowCakePopup] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);

  // Touch/Swipe handling
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const minSwipeDistance = 50;

  // Data for pages
  const wishes = [
    { text: "May you always find reasons to smile, even on the hardest days", icon: "✨" },
    { text: "Surrounded by people who see you, hear you, and love you for exactly who you are", icon: "💕" },
    { text: "May your dreams unfold gently, in their own perfect timing", icon: "🌸" },
    { text: "Never forget how strong you are, even when you feel fragile", icon: "💪" },
    { text: "May you be as kind to yourself as you are to others", icon: "💖" },
    { text: "Finding peace in the little moments that make life beautiful", icon: "🌙" },
    { text: "May you always trust your journey, even when the path isn't clear", icon: "🦋" },
    { text: "Feeling proud of how far you've come and excited for where you're going", icon: "🌟" },
  ];

  const pages = [
    <HeroPage key="hero" />,
    <WishesPage key="wishes" wishes={wishes} />,
    <MiniGamesPage key="minigames" />,
    <MagicMirrorPage key="magicmirror" />,
    <DigitalScrapbookPage key="reminders" />,
    <LetterPage key="letter" />,
    <GoodbyePage key="goodbye" />,
  ];

  const totalPages = pages.length;

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const cards = document.querySelectorAll('.tilt-card');
      cards.forEach((card) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        (card as HTMLElement).style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showIntro || showCakePopup) return;
      
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        setCurrentPage((prev) => Math.min(prev + 1, totalPages - 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        setCurrentPage((prev) => Math.max(prev - 1, 0));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showIntro, showCakePopup, totalPages]);

  const handleIntroComplete = () => {
    setShowIntro(false);
    setTimeout(() => {
      setShowCakePopup(true);
    }, 200);
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientY);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientY);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isDownSwipe = distance > minSwipeDistance;
    const isUpSwipe = distance < -minSwipeDistance;
    
    if (isDownSwipe) {
      setCurrentPage((prev) => Math.min(prev + 1, totalPages - 1));
    }
    if (isUpSwipe) {
      setCurrentPage((prev) => Math.max(prev - 1, 0));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-rose-50">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap');
        
        .font-playfair {
          font-family: 'Playfair Display', serif;
        }
        
        .font-poppins {
          font-family: 'Poppins', sans-serif;
        }

        body {
          font-family: 'Poppins', sans-serif;
          overflow-y: auto;
          overflow-x: hidden;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        * {
          -webkit-tap-highlight-color: transparent;
        }

        .tilt-card {
          transition: transform 0.1s ease-out;
        }

        .tilt-card:not(:hover) {
          transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1) !important;
          transition: transform 0.5s ease-out;
        }

        /* Optimize for mobile */
        @media (max-width: 640px) {
          body {
            font-size: 16px; /* Prevent iOS zoom on input focus */
          }
        }

        /* Better touch targets */
        button, a {
          min-width: 44px;
          min-height: 44px;
        }

        /* Smooth scrolling */
        html {
          scroll-behavior: smooth;
        }

        /* Hide scrollbar but keep functionality */
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>

      {/* Intro Animation */}
      <AnimatePresence>
        {showIntro && <IntroAnimation onComplete={handleIntroComplete} />}
      </AnimatePresence>

      {/* Birthday Cake Popup */}
      <BirthdayCakePopup isOpen={showCakePopup} onComplete={() => setShowCakePopup(false)} />

      {/* Main Content with Page Transitions */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: (showIntro || showCakePopup) ? 0 : 1 }}
        transition={{ duration: 0.8 }}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ 
              duration: 0.5,
              ease: [0.4, 0, 0.2, 1]
            }}
          >
            {pages[currentPage]}
          </motion.div>
        </AnimatePresence>

        {/* Page Navigation */}
        {!showIntro && !showCakePopup && (
          <PageNavigation
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        )}
      </motion.div>
    </div>
  );
}