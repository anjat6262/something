import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { BirthdayCake } from './BirthdayCake';
import { CatPaw, PlayfulCat, CatWithHeart } from './CatIllustrations';

interface BirthdayCakePopupProps {
  isOpen: boolean;
  onComplete: () => void;
}

export const BirthdayCakePopup = ({ isOpen, onComplete }: BirthdayCakePopupProps) => {
  const [showInstruction, setShowInstruction] = useState(true);
  const [candlesBlown, setCandlesBlown] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Hide instruction after a few seconds
      const timer = setTimeout(() => {
        setShowInstruction(false);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleCandlesBlown = () => {
    setCandlesBlown(true);
    setShowCelebration(true);
    
    // Wait for celebration animation, then close
    setTimeout(() => {
      onComplete();
    }, 3500);
  };

  // Natural spring config for realistic motion
  const springConfig = {
    type: "spring",
    stiffness: 100,
    damping: 15,
    mass: 0.8
  };

  const smoothSpring = {
    type: "spring",
    stiffness: 80,
    damping: 20,
    mass: 1
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
        >
          {/* Animated gradient background with smooth wave */}
          <motion.div
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            style={{
              background: 'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 25%, #f9a8d4 50%, #f472b6 75%, #ec4899 100%)',
              backgroundSize: '400% 400%',
            }}
          >
            <motion.div
              className="absolute inset-0"
              animate={{
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{
                duration: 15,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              style={{
                background: 'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 25%, #f9a8d4 50%, #f472b6 75%, #ec4899 100%)',
                backgroundSize: '400% 400%',
              }}
            />
          </motion.div>

          {/* Soft spotlight effect from top */}
          <motion.div
            className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px]"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ 
              opacity: [0.2, 0.35, 0.2],
              scale: [0.9, 1.1, 0.9]
            }}
            transition={{ 
              opacity: { duration: 4, repeat: Infinity, ease: "easeInOut" },
              scale: { duration: 6, repeat: Infinity, ease: "easeInOut" }
            }}
            style={{
              background: 'radial-gradient(circle, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.3) 40%, transparent 70%)',
            }}
          />

          {/* Magical particles floating around - more organic motion */}
          {!showCelebration && (
            <>
              {[...Array(20)].map((_, i) => {
                const startX = Math.random() * window.innerWidth;
                const drift = (Math.random() - 0.5) * 200;
                
                return (
                  <motion.div
                    key={`particle-${i}`}
                    className="absolute text-2xl"
                    initial={{
                      x: startX,
                      y: window.innerHeight + 50,
                      opacity: 0,
                      scale: 0.3,
                      rotate: Math.random() * 360
                    }}
                    animate={{
                      y: -100,
                      x: startX + drift,
                      opacity: [0, 0.8, 0.8, 0],
                      rotate: [0, 180 + Math.random() * 180],
                      scale: [0.3, 1, 1, 0.3],
                    }}
                    transition={{
                      duration: 5 + Math.random() * 4,
                      repeat: Infinity,
                      delay: Math.random() * 3,
                      ease: [0.4, 0, 0.2, 1]
                    }}
                  >
                    {['✨', '💫', '⭐', '🌟', '💖', '💕'][Math.floor(Math.random() * 6)]}
                  </motion.div>
                );
              })}
            </>
          )}

          {/* Floating decorative cat elements - natural bouncing */}
          {!showCelebration && (
            <>
              <motion.div
                className="absolute top-20 left-10 text-pink-300/40"
                initial={{ opacity: 0, scale: 0, rotate: -30 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  rotate: 0,
                  y: [0, -15, 0],
                }}
                transition={{
                  opacity: { duration: 0.8, ease: "easeOut" },
                  scale: { ...smoothSpring, delay: 0.2 },
                  rotate: { duration: 1, ease: [0.4, 0, 0.2, 1], delay: 0.2 },
                  y: {
                    duration: 3.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }
                }}
              >
                <PlayfulCat className="w-24 h-24" />
              </motion.div>
              
              <motion.div
                className="absolute top-20 right-10 text-pink-300/40"
                initial={{ opacity: 0, scale: 0, rotate: 30 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  rotate: 0,
                  y: [0, -20, 0],
                }}
                transition={{
                  opacity: { duration: 0.8, ease: "easeOut" },
                  scale: { ...smoothSpring, delay: 0.3 },
                  rotate: { duration: 1, ease: [0.4, 0, 0.2, 1], delay: 0.3 },
                  y: {
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5
                  }
                }}
              >
                <CatWithHeart className="w-24 h-24" />
              </motion.div>
              
              <motion.div
                className="absolute bottom-20 left-20 text-pink-300/30"
                initial={{ opacity: 0, x: -80, rotate: -45 }}
                animate={{
                  opacity: 1,
                  x: 0,
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.05, 1],
                }}
                transition={{
                  opacity: { duration: 0.8, ease: "easeOut" },
                  x: { ...smoothSpring, delay: 0.4 },
                  rotate: {
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  },
                  scale: {
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }
                }}
              >
                <CatPaw className="w-16 h-16" />
              </motion.div>
              
              <motion.div
                className="absolute bottom-20 right-20 text-pink-300/30"
                initial={{ opacity: 0, x: 80, rotate: 45 }}
                animate={{
                  opacity: 1,
                  x: 0,
                  rotate: [0, -10, 10, 0],
                  scale: [1, 1.05, 1],
                }}
                transition={{
                  opacity: { duration: 0.8, ease: "easeOut" },
                  x: { ...smoothSpring, delay: 0.5 },
                  rotate: {
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                  },
                  scale: {
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                  }
                }}
              >
                <CatPaw className="w-16 h-16" />
              </motion.div>
            </>
          )}

          {/* Main content */}
          <div className="relative z-10 w-full max-w-2xl mx-auto px-6">
            {/* Title with smooth entrance */}
            {!candlesBlown && (
              <motion.div
                className="text-center mb-8"
                initial={{ opacity: 0, y: -30, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ 
                  ...smoothSpring,
                  delay: 0.4
                }}
              >
                <motion.h1
                  className="font-playfair text-5xl md:text-7xl text-white mb-4"
                  animate={{
                    textShadow: [
                      '0 0 20px rgba(255, 255, 255, 0.5), 0 0 40px rgba(236, 72, 153, 0.3)',
                      '0 0 30px rgba(255, 255, 255, 0.7), 0 0 50px rgba(236, 72, 153, 0.4)',
                      '0 0 20px rgba(255, 255, 255, 0.5), 0 0 40px rgba(236, 72, 153, 0.3)',
                    ],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  Make a Wish! 🎂
                </motion.h1>
              </motion.div>
            )}

            {/* Birthday Cake with smooth entrance */}
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: 80 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ 
                ...springConfig,
                delay: 0.6
              }}
            >
              {/* Soft glow effect behind cake */}
              <motion.div
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full"
                animate={{
                  scale: [1, 1.15, 1],
                  opacity: [0.25, 0.4, 0.25],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                style={{
                  background: 'radial-gradient(circle, rgba(251, 207, 232, 0.9) 0%, rgba(251, 207, 232, 0.3) 50%, transparent 70%)',
                }}
              />
              
              <BirthdayCake onCandlesBlown={handleCandlesBlown} isPopup={true} />
            </motion.div>

            {/* Instruction text with gentle pulse */}
            <AnimatePresence>
              {showInstruction && !candlesBlown && (
                <motion.div
                  className="text-center mt-8"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.6, delay: 1, ease: "easeOut" }}
                >
                  <motion.p
                    className="font-poppins text-white text-xl md:text-2xl"
                    style={{ fontWeight: 300 }}
                    animate={{
                      scale: [1, 1.03, 1],
                      textShadow: [
                        '0 0 10px rgba(255, 255, 255, 0.5)',
                        '0 0 15px rgba(255, 255, 255, 0.7)',
                        '0 0 10px rgba(255, 255, 255, 0.5)',
                      ],
                    }}
                    transition={{
                      duration: 2.5,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    Click the candles to blow them out! 🕯️✨
                  </motion.p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Celebration confetti and message */}
            <AnimatePresence>
              {showCelebration && (
                <>
                  {/* Confetti explosion with natural physics */}
                  {[...Array(50)].map((_, i) => {
                    const angle = (i / 50) * 360;
                    const distance = 150 + Math.random() * 300;
                    const x = Math.cos(angle * Math.PI / 180) * distance;
                    const y = Math.sin(angle * Math.PI / 180) * distance;
                    const rotation = Math.random() * 1080 - 540;
                    
                    return (
                      <motion.div
                        key={i}
                        className="absolute text-2xl md:text-3xl"
                        initial={{
                          x: '50vw',
                          y: '50vh',
                          opacity: 1,
                          scale: 0,
                          rotate: 0
                        }}
                        animate={{
                          x: `calc(50vw + ${x}px)`,
                          y: `calc(50vh + ${y}px)`,
                          opacity: [1, 1, 0.8, 0],
                          scale: [0, 1.5, 1.2, 0.8],
                          rotate: rotation,
                        }}
                        transition={{
                          duration: 2 + Math.random() * 1,
                          ease: [0.4, 0, 0.2, 1]
                        }}
                      >
                        {['🎉', '✨', '💕', '🎊', '⭐', '💖', '🌸', '🎈', '🎁', '💗'][Math.floor(Math.random() * 10)]}
                      </motion.div>
                    );
                  })}

                  {/* Firework bursts with realistic timing */}
                  {[...Array(6)].map((_, i) => (
                    <motion.div
                      key={`firework-${i}`}
                      className="absolute"
                      style={{
                        left: `${25 + Math.random() * 50}%`,
                        top: `${25 + Math.random() * 50}%`,
                      }}
                    >
                      {[...Array(12)].map((_, j) => {
                        const angle = (j / 12) * 360;
                        const distance = 60 + Math.random() * 40;
                        return (
                          <motion.div
                            key={`spark-${j}`}
                            className="absolute w-2 h-2 rounded-full bg-white"
                            initial={{ scale: 0, opacity: 1 }}
                            animate={{
                              x: Math.cos(angle * Math.PI / 180) * distance,
                              y: Math.sin(angle * Math.PI / 180) * distance,
                              scale: [0, 1.2, 0],
                              opacity: [1, 1, 0],
                            }}
                            transition={{
                              duration: 1.2,
                              delay: i * 0.2,
                              ease: [0.4, 0, 0.6, 1]
                            }}
                          />
                        );
                      })}
                    </motion.div>
                  ))}

                  {/* Celebration message with smooth reveal */}
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center"
                    initial={{ opacity: 0, scale: 0.7 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ 
                      ...smoothSpring,
                      delay: 0.4
                    }}
                  >
                    <motion.div
                      className="text-center"
                      animate={{
                        scale: [1, 1.03, 1],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: 2,
                        delay: 0.8,
                        ease: "easeInOut"
                      }}
                    >
                      <motion.h2
                        className="font-playfair text-6xl md:text-8xl text-white mb-6"
                        style={{
                          textShadow: '0 0 40px rgba(255, 255, 255, 0.8), 0 0 80px rgba(236, 72, 153, 0.6)',
                        }}
                        initial={{ opacity: 0, rotateX: -90 }}
                        animate={{ opacity: 1, rotateX: 0 }}
                        transition={{ 
                          duration: 1, 
                          delay: 0.4,
                          ease: [0.4, 0, 0.2, 1]
                        }}
                      >
                        Happy Birthday! 🎉
                      </motion.h2>
                      <motion.p
                        className="font-poppins text-white text-2xl md:text-4xl"
                        style={{ 
                          fontWeight: 300,
                          textShadow: '0 0 20px rgba(255, 255, 255, 0.6)',
                        }}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ 
                          duration: 0.8, 
                          delay: 0.9,
                          ease: "easeOut"
                        }}
                      >
                        May all your wishes come true! ✨
                      </motion.p>
                    </motion.div>
                  </motion.div>

                  {/* Expanding sparkle rings with natural easing */}
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={`ring-${i}`}
                      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-white/40"
                      initial={{ width: 0, height: 0, opacity: 0.8 }}
                      animate={{
                        width: ['0px', '1000px'],
                        height: ['0px', '1000px'],
                        opacity: [0.8, 0.4, 0],
                        borderWidth: ['4px', '2px', '0px'],
                      }}
                      transition={{
                        duration: 2.5,
                        delay: i * 0.3,
                        ease: [0.4, 0, 0.2, 1]
                      }}
                    />
                  ))}
                </>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};