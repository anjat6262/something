import { motion } from 'motion/react';
import { useState, useEffect } from 'react';

interface BirthdayCakeProps {
  onCandlesBlown?: () => void;
  isPopup?: boolean;
}

export const BirthdayCake = ({ onCandlesBlown, isPopup = false }: BirthdayCakeProps = {}) => {
  const [isLit, setIsLit] = useState(true);
  const [showWish, setShowWish] = useState(false);

  const handleBlowCandles = () => {
    setIsLit(false);
    setTimeout(() => {
      setShowWish(true);
      if (onCandlesBlown) {
        onCandlesBlown();
      }
    }, 500);
    
    if (!isPopup) {
      setTimeout(() => {
        setIsLit(true);
        setShowWish(false);
      }, 3000);
    }
  };

  return (
    <div className="relative flex flex-col items-center">
      {/* Wish text that appears when candles are blown */}
      {showWish && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.8 }}
          animate={{ opacity: 1, y: -30, scale: 1 }}
          exit={{ opacity: 0 }}
          className="absolute -top-20 text-center"
        >
          <p className="font-playfair text-rose-900 text-xl">✨ Make a wish! ✨</p>
        </motion.div>
      )}

      <motion.div
        className="relative cursor-pointer"
        onClick={handleBlowCandles}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.98 }}
        transition={{ 
          type: "spring",
          stiffness: 300,
          damping: 20
        }}
      >
        <svg
          width="200"
          height="220"
          viewBox="0 0 200 220"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Candles */}
          <g>
            {/* Left Candle */}
            <rect x="60" y="20" width="8" height="35" fill="#fef3c7" stroke="#fcd34d" strokeWidth="1" />
            {/* Middle Candle */}
            <rect x="96" y="15" width="8" height="40" fill="#fef3c7" stroke="#fcd34d" strokeWidth="1" />
            {/* Right Candle */}
            <rect x="132" y="20" width="8" height="35" fill="#fef3c7" stroke="#fcd34d" strokeWidth="1" />

            {/* Flames */}
            {isLit && (
              <>
                {/* Left Flame */}
                <motion.g
                  animate={{
                    y: [0, -3, 0],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 0.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <ellipse cx="64" cy="15" rx="6" ry="10" fill="#fbbf24" opacity="0.8" />
                  <ellipse cx="64" cy="13" rx="4" ry="7" fill="#fef08a" />
                  <ellipse cx="64" cy="11" rx="2" ry="4" fill="#fffbeb" />
                </motion.g>

                {/* Middle Flame */}
                <motion.g
                  animate={{
                    y: [0, -3, 0],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 0.6,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.1,
                  }}
                >
                  <ellipse cx="100" cy="10" rx="6" ry="10" fill="#fbbf24" opacity="0.8" />
                  <ellipse cx="100" cy="8" rx="4" ry="7" fill="#fef08a" />
                  <ellipse cx="100" cy="6" rx="2" ry="4" fill="#fffbeb" />
                </motion.g>

                {/* Right Flame */}
                <motion.g
                  animate={{
                    y: [0, -3, 0],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 0.55,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.2,
                  }}
                >
                  <ellipse cx="136" cy="15" rx="6" ry="10" fill="#fbbf24" opacity="0.8" />
                  <ellipse cx="136" cy="13" rx="4" ry="7" fill="#fef08a" />
                  <ellipse cx="136" cy="11" rx="2" ry="4" fill="#fffbeb" />
                </motion.g>

                {/* Glow effect */}
                <motion.circle
                  cx="100"
                  cy="12"
                  r="50"
                  fill="url(#candleGlow)"
                  animate={{
                    opacity: [0.1, 0.2, 0.1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                />
              </>
            )}

            {/* Smoke when blown out */}
            {!isLit && (
              <>
                <motion.path
                  d="M 64 20 Q 66 10 68 0"
                  stroke="#94a3b8"
                  strokeWidth="2"
                  fill="none"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: [0, 0.6, 0] }}
                  transition={{ duration: 1.5 }}
                />
                <motion.path
                  d="M 100 15 Q 102 5 104 -5"
                  stroke="#94a3b8"
                  strokeWidth="2"
                  fill="none"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: [0, 0.6, 0] }}
                  transition={{ duration: 1.5, delay: 0.1 }}
                />
                <motion.path
                  d="M 136 20 Q 138 10 140 0"
                  stroke="#94a3b8"
                  strokeWidth="2"
                  fill="none"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: [0, 0.6, 0] }}
                  transition={{ duration: 1.5, delay: 0.2 }}
                />
              </>
            )}
          </g>

          {/* Top Frosting Layer */}
          <motion.path
            d="M 30 55 Q 40 50 50 55 Q 60 60 70 55 Q 80 50 90 55 Q 100 60 110 55 Q 120 50 130 55 Q 140 60 150 55 Q 160 50 170 55 L 170 75 L 30 75 Z"
            fill="#fbcfe8"
            stroke="#f9a8d4"
            strokeWidth="2"
            animate={{
              y: [0, -2, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Cake Layer 1 - Top */}
          <motion.rect
            x="30"
            y="75"
            width="140"
            height="40"
            rx="5"
            fill="#fce7f3"
            stroke="#fbcfe8"
            strokeWidth="2"
            animate={{
              scaleX: [1, 1.02, 1],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Decorative dots on layer 1 */}
          <circle cx="50" cy="95" r="3" fill="#f9a8d4" />
          <circle cx="70" cy="95" r="3" fill="#f9a8d4" />
          <circle cx="90" cy="95" r="3" fill="#f9a8d4" />
          <circle cx="110" cy="95" r="3" fill="#f9a8d4" />
          <circle cx="130" cy="95" r="3" fill="#f9a8d4" />
          <circle cx="150" cy="95" r="3" fill="#f9a8d4" />

          {/* Middle Frosting */}
          <path
            d="M 35 115 Q 45 110 55 115 Q 65 120 75 115 Q 85 110 95 115 Q 105 120 115 115 Q 125 110 135 115 Q 145 120 155 115 Q 165 110 165 115 L 165 125 L 35 125 Z"
            fill="#fbcfe8"
            stroke="#f9a8d4"
            strokeWidth="2"
          />

          {/* Cake Layer 2 - Middle */}
          <motion.rect
            x="35"
            y="125"
            width="130"
            height="40"
            rx="5"
            fill="#fce7f3"
            stroke="#fbcfe8"
            strokeWidth="2"
            animate={{
              scaleX: [1, 1.02, 1],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5,
            }}
          />

          {/* Heart decorations on layer 2 */}
          <motion.path
            d="M 60 145 C 60 142 63 140 65 142 C 67 140 70 142 70 145 C 70 148 65 152 65 152 C 65 152 60 148 60 145 Z"
            fill="#f472b6"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              delay: 0.2,
            }}
          />
          <motion.path
            d="M 95 145 C 95 142 98 140 100 142 C 102 140 105 142 105 145 C 105 148 100 152 100 152 C 100 152 95 148 95 145 Z"
            fill="#f472b6"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              delay: 0.4,
            }}
          />
          <motion.path
            d="M 130 145 C 130 142 133 140 135 142 C 137 140 140 142 140 145 C 140 148 135 152 135 152 C 135 152 130 148 130 145 Z"
            fill="#f472b6"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              delay: 0.6,
            }}
          />

          {/* Bottom Frosting */}
          <path
            d="M 40 165 Q 50 160 60 165 Q 70 170 80 165 Q 90 160 100 165 Q 110 170 120 165 Q 130 160 140 165 Q 150 170 160 165 L 160 175 L 40 175 Z"
            fill="#fbcfe8"
            stroke="#f9a8d4"
            strokeWidth="2"
          />

          {/* Cake Layer 3 - Bottom (Plate) */}
          <motion.rect
            x="40"
            y="175"
            width="120"
            height="35"
            rx="5"
            fill="#fce7f3"
            stroke="#fbcfe8"
            strokeWidth="2"
            animate={{
              scaleX: [1, 1.02, 1],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1,
            }}
          />

          {/* Plate */}
          <ellipse cx="100" cy="210" rx="80" ry="8" fill="#fdf2f8" stroke="#fbcfe8" strokeWidth="2" />

          {/* Gradient definitions */}
          <defs>
            <radialGradient id="candleGlow">
              <stop offset="0%" stopColor="#fef08a" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#fef08a" stopOpacity="0" />
            </radialGradient>
          </defs>
        </svg>

        {/* Sparkles around the cake */}
        <motion.div
          className="absolute top-0 left-0 text-2xl"
          animate={{
            rotate: [0, 360],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
        >
          ✨
        </motion.div>
        <motion.div
          className="absolute top-0 right-0 text-2xl"
          animate={{
            rotate: [360, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: 0.5,
          }}
        >
          ✨
        </motion.div>
        <motion.div
          className="absolute bottom-10 left-5 text-xl"
          animate={{
            y: [0, -10, 0],
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            delay: 1,
          }}
        >
          💫
        </motion.div>
        <motion.div
          className="absolute bottom-10 right-5 text-xl"
          animate={{
            y: [0, -10, 0],
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            delay: 1.5,
          }}
        >
          💫
        </motion.div>
      </motion.div>

      <motion.p
        className="mt-6 text-rose-700/60 text-sm font-poppins italic"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
        style={{ fontWeight: 300 }}
      >
        Click to blow the candles! 🎂
      </motion.p>
    </div>
  );
};