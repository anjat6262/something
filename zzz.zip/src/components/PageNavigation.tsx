import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PageNavigationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export const PageNavigation = ({ currentPage, totalPages, onPageChange }: PageNavigationProps) => {
  const canGoPrev = currentPage > 0;
  const canGoNext = currentPage < totalPages - 1;

  return (
    <div className="fixed bottom-6 sm:bottom-8 left-0 right-0 z-40 px-4">
      <div className="max-w-md mx-auto">
        <motion.div
          className="bg-white/80 backdrop-blur-xl rounded-full shadow-2xl border border-rose-100/50 px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2 sm:gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          {/* Previous Button */}
          <motion.button
            onClick={() => canGoPrev && onPageChange(currentPage - 1)}
            disabled={!canGoPrev}
            className={`p-2 rounded-full transition-all duration-300 touch-manipulation flex-shrink-0 ${
              canGoPrev
                ? 'bg-rose-100 hover:bg-rose-200 text-rose-700 cursor-pointer active:bg-rose-300'
                : 'bg-gray-100 text-gray-300 cursor-not-allowed'
            }`}
            whileHover={canGoPrev ? { scale: 1.1 } : {}}
            whileTap={canGoPrev ? { scale: 0.9 } : {}}
          >
            <ChevronLeft className="w-5 h-5" />
          </motion.button>

          {/* Page Indicators */}
          <div className="flex items-center gap-1 sm:gap-1.5 flex-1 justify-center overflow-x-auto scrollbar-hide px-1">
            {Array.from({ length: totalPages }).map((_, index) => (
              <motion.button
                key={index}
                onClick={() => onPageChange(index)}
                className="relative touch-manipulation flex items-center justify-center flex-shrink-0"
                style={{ minWidth: '40px', minHeight: '40px' }}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.9 }}
              >
                <motion.div
                  className={`rounded-full transition-all duration-300 ${
                    index === currentPage
                      ? 'w-6 sm:w-8 h-2.5 sm:h-3 bg-gradient-to-r from-rose-400 to-pink-400'
                      : 'w-2.5 sm:w-3 h-2.5 sm:h-3 bg-rose-200 hover:bg-rose-300'
                  }`}
                  animate={index === currentPage ? { scale: [1, 1.1, 1] } : {}}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </motion.button>
            ))}
          </div>

          {/* Next Button */}
          <motion.button
            onClick={() => canGoNext && onPageChange(currentPage + 1)}
            disabled={!canGoNext}
            className={`p-2 rounded-full transition-all duration-300 touch-manipulation flex-shrink-0 ${
              canGoNext
                ? 'bg-rose-100 hover:bg-rose-200 text-rose-700 cursor-pointer active:bg-rose-300'
                : 'bg-gray-100 text-gray-300 cursor-not-allowed'
            }`}
            whileHover={canGoNext ? { scale: 1.1 } : {}}
            whileTap={canGoNext ? { scale: 0.9 } : {}}
          >
            <ChevronRight className="w-5 h-5" />
          </motion.button>
        </motion.div>

        {/* Page Counter Text */}
        <motion.div
          className="text-center mt-2 sm:mt-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          <p className="font-poppins text-rose-600/60 text-xs sm:text-sm" style={{ fontWeight: 300 }}>
            {currentPage + 1} of {totalPages}
          </p>
        </motion.div>
      </div>
    </div>
  );
};