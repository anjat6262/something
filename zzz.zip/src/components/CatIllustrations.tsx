// Elegant minimal cat illustrations and icons

export const SittingCat = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Sitting cat silhouette - elegant and minimal */}
    <path
      d="M40 30 L35 15 L45 20 L50 10 L52 22 L60 18 L58 28 C58 28 75 35 78 60 C78 70 75 85 65 90 C60 92 50 92 45 90 C35 85 32 70 32 60 C32 45 40 35 40 30 Z"
      stroke="currentColor"
      strokeWidth="1.5"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      opacity="0.6"
    />
    <circle cx="48" cy="50" r="2" fill="currentColor" opacity="0.6" />
    <circle cx="62" cy="50" r="2" fill="currentColor" opacity="0.6" />
  </svg>
);

export const PlayfulCat = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Playful cat with tail up */}
    <path
      d="M30 20 L25 8 L32 15 L35 5 L36 18 C36 18 45 25 45 40 C45 50 42 60 38 62"
      stroke="currentColor"
      strokeWidth="1.5"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      opacity="0.5"
    />
    <ellipse cx="42" cy="65" rx="15" ry="12" stroke="currentColor" strokeWidth="1.5" fill="none" opacity="0.5" />
    <path
      d="M55 70 Q65 68 75 75 M55 72 Q62 80 68 85"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      fill="none"
      opacity="0.5"
    />
    {/* Curved tail */}
    <path
      d="M50 60 Q60 40 70 35 Q75 33 78 38"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      fill="none"
      opacity="0.5"
    />
    <circle cx="38" cy="63" r="1.5" fill="currentColor" opacity="0.5" />
    <circle cx="46" cy="63" r="1.5" fill="currentColor" opacity="0.5" />
  </svg>
);

export const SleepingCat = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 120 80"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Sleeping curled up cat */}
    <path
      d="M30 50 Q20 45 15 40 C15 40 10 35 12 28 L18 25 L22 30 C25 25 35 20 50 22 C65 24 75 30 78 40 Q80 48 75 55 Q70 62 60 65 Q45 68 35 62 Q30 58 30 50 Z"
      stroke="currentColor"
      strokeWidth="1.5"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      opacity="0.4"
    />
    {/* Closed eyes */}
    <path d="M35 45 Q38 44 41 45" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
    <path d="M50 43 Q53 42 56 43" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
    {/* Ears */}
    <path d="M20 30 L15 20 L25 28" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.4" />
    <path d="M30 28 L28 18 L35 26" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.4" />
    {/* ZZZ */}
    <text x="70" y="25" fill="currentColor" opacity="0.3" fontSize="12" fontFamily="sans-serif">z</text>
    <text x="78" y="20" fill="currentColor" opacity="0.3" fontSize="10" fontFamily="sans-serif">z</text>
    <text x="84" y="16" fill="currentColor" opacity="0.3" fontSize="8" fontFamily="sans-serif">z</text>
  </svg>
);

export const StretchingCat = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 200 80"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Stretching cat - elegant line art */}
    <path
      d="M20 40 Q30 35 40 38 L60 40 L80 38 Q100 36 120 40 L140 42 Q160 40 180 45"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      fill="none"
      opacity="0.5"
    />
    <ellipse cx="35" cy="38" rx="8" ry="6" stroke="currentColor" strokeWidth="1.5" fill="none" opacity="0.5" />
    <path d="M30 30 L28 20 L35 25" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.5" />
    <path d="M40 30 L42 20 L37 25" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.5" />
    <circle cx="32" cy="36" r="1.5" fill="currentColor" opacity="0.5" />
    <circle cx="38" cy="36" r="1.5" fill="currentColor" opacity="0.5" />
    <path d="M20 40 L15 50 L18 52" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.5" />
    <path d="M180 45 L185 55 L182 57" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.5" />
  </svg>
);

export const CatWithHeart = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Cat head with heart */}
    <path
      d="M20 25 L15 10 L22 20 C22 20 18 28 18 40 C18 52 25 60 35 62 C40 63 45 63 50 62 C60 60 67 52 67 40 C67 28 63 20 63 20 L70 10 L65 25"
      stroke="currentColor"
      strokeWidth="1.2"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      opacity="0.45"
    />
    <circle cx="30" cy="40" r="2" fill="currentColor" opacity="0.5" />
    <circle cx="52" cy="40" r="2" fill="currentColor" opacity="0.5" />
    <path
      d="M41 45 L39 50 M41 45 L43 50"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      opacity="0.4"
    />
    {/* Heart above */}
    <path
      d="M35 5 C35 3 37 1 39 2 C41 1 43 3 43 5 C43 8 39 12 39 12 C39 12 35 8 35 5 Z"
      fill="currentColor"
      opacity="0.3"
    />
  </svg>
);

export const CatPaw = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Cat paw print - subtle and minimal */}
    <ellipse cx="20" cy="25" rx="6" ry="7" fill="currentColor" opacity="0.15" />
    <ellipse cx="14" cy="15" rx="3" ry="4" fill="currentColor" opacity="0.15" />
    <ellipse cx="20" cy="13" rx="3" ry="4" fill="currentColor" opacity="0.15" />
    <ellipse cx="26" cy="15" rx="3" ry="4" fill="currentColor" opacity="0.15" />
  </svg>
);

export const CatFace = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 60 60"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Minimal cat face for hero section */}
    <path
      d="M15 10 L10 5 L12 15 C12 15 8 20 8 30 C8 42 15 50 30 50 C45 50 52 42 52 30 C52 20 48 15 48 15 L50 5 L45 10"
      stroke="currentColor"
      strokeWidth="1.2"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      opacity="0.4"
    />
    <circle cx="22" cy="28" r="2" fill="currentColor" opacity="0.5" />
    <circle cx="38" cy="28" r="2" fill="currentColor" opacity="0.5" />
    <path
      d="M30 32 L28 36 M30 32 L32 36"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      opacity="0.4"
    />
    <path
      d="M25 35 Q30 38 35 35"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      fill="none"
      opacity="0.4"
    />
  </svg>
);

export const TinyCatSilhouette = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    {/* Tiny sitting cat for footer */}
    <path
      d="M15 12 L13 5 L17 8 L20 4 L21 9 L24 7 L23 12 C23 12 28 15 29 24 C29 28 28 33 24 35 C22 36 20 36 18 35 C14 33 13 28 13 24 C13 18 15 14 15 12 Z"
      fill="currentColor"
      opacity="0.3"
    />
  </svg>
);