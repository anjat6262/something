import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { CatFace, CatPaw } from './CatIllustrations';

interface IntroAnimationProps {
  onComplete: () => void;
}

export const IntroAnimation = ({ onComplete }: IntroAnimationProps) => {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    const timer1 = setTimeout(() => setStage(1), 500);
    const timer2 = setTimeout(() => setStage(2), 2000);
    const timer3 = setTimeout(() => setStage(3), 3500);
    const timer4 = setTimeout(() => onComplete(), 4500);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 50%, #f9a8d4 100%)',
        }}
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 1 }}
      >
        {/* Animated background particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-pink-300/20"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -30, 0],
                x: [0, Math.random() * 20 - 10, 0],
                rotate: [0, 360],
                opacity: [0.2, 0.5, 0.2],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            >
              <CatPaw className="w-8 h-8" />
            </motion.div>
          ))}
        </div>

        {/* Main content */}
        <div className="relative z-10 text-center px-6">
          {/* Cat illustration */}
          <motion.div
            className="flex justify-center mb-8"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: stage >= 1 ? 1 : 0, rotate: 0 }}
            transition={{ duration: 0.8, type: "spring", bounce: 0.5 }}
          >
            <motion.div
              className="text-rose-400"
              animate={stage >= 1 ? {
                y: [0, -10, 0],
                rotate: [0, 5, -5, 0],
              } : {}}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <CatFace className="w-32 h-32 md:w-40 md:h-40" />
            </motion.div>
          </motion.div>

          {/* Text animations */}
          <div className="space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: stage >= 1 ? 1 : 0, 
                y: stage >= 1 ? 0 : 20 
              }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <h1 className="font-playfair text-4xl md:text-6xl text-rose-900">
                Happy Birthday
              </h1>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ 
                opacity: stage >= 2 ? 1 : 0, 
                scale: stage >= 2 ? 1 : 0.8 
              }}
              transition={{ duration: 0.6 }}
              className="flex justify-center gap-3"
            >
              {['🎂', '🎉', '🎈', '✨', '🐱'].map((emoji, i) => (
                <motion.span
                  key={i}
                  className="text-3xl md:text-4xl"
                  animate={stage >= 2 ? {
                    y: [0, -15, 0],
                    rotate: [0, 10, -10, 0],
                  } : {}}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    delay: i * 0.1,
                  }}
                >
                  {emoji}
                </motion.span>
              ))}
            </motion.div>

            <motion.p
              className="font-poppins text-rose-700 text-lg md:text-xl"
              style={{ fontWeight: 300 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: stage >= 2 ? 1 : 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              Get ready for something special...
            </motion.p>
          </div>

          {/* Loading animation */}
          <motion.div
            className="mt-12 flex justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: stage >= 2 ? 1 : 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex gap-2">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="w-3 h-3 bg-rose-400 rounded-full"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    delay: i * 0.2,
                  }}
                />
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sparkles */}
        {stage >= 3 && (
          <>
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={`sparkle-${i}`}
                className="absolute text-2xl"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ 
                  scale: [0, 1.5, 0],
                  opacity: [0, 1, 0],
                  rotate: [0, 180, 360],
                }}
                transition={{
                  duration: 1,
                  delay: Math.random() * 0.5,
                }}
              >
                ✨
              </motion.div>
            ))}
          </>
        )}
      </motion.div>
    </AnimatePresence>
  );
};
