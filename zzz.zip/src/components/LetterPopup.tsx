import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { CatPaw } from './CatIllustrations';

interface LetterPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LetterPopup = ({ isOpen, onClose }: LetterPopupProps) => {
  const [isOpened, setIsOpened] = useState(false);

  const handleOpen = () => {
    setIsOpened(true);
  };

  const handleClose = () => {
    setIsOpened(false);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          {/* Backdrop blur */}
          <motion.div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Letter container */}
          <motion.div
            className="relative z-10 max-w-2xl w-full"
            onClick={(e) => e.stopPropagation()}
            initial={{ scale: 0.5, opacity: 0, y: 100 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.5, opacity: 0, y: 100 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
          >
            {!isOpened ? (
              // Closed envelope
              <motion.div
                className="relative cursor-pointer"
                onClick={handleOpen}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {/* Envelope body */}
                <motion.div
                  className="relative bg-gradient-to-br from-rose-200 to-pink-300 rounded-lg shadow-2xl p-8 md:p-12"
                  style={{
                    aspectRatio: '16/10',
                  }}
                >
                  {/* Envelope flap shadow */}
                  <div className="absolute inset-0 bg-gradient-to-b from-rose-300/50 to-transparent rounded-t-lg" style={{ height: '40%' }} />

                  {/* Decorative seal */}
                  <motion.div
                    className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
                    animate={{
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.05, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  >
                    <div className="w-20 h-20 bg-gradient-to-br from-amber-200 to-amber-300 rounded-full shadow-lg flex items-center justify-center border-4 border-amber-400/50">
                      <span className="text-3xl">💌</span>
                    </div>
                  </motion.div>

                  {/* Cat paw decorations */}
                  <motion.div
                    className="absolute top-4 right-4 text-rose-400/30"
                    animate={{ rotate: [0, 10, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <CatPaw className="w-10 h-10" />
                  </motion.div>
                  <motion.div
                    className="absolute bottom-4 left-4 text-rose-400/30"
                    animate={{ rotate: [0, -10, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity }}
                  >
                    <CatPaw className="w-10 h-10" />
                  </motion.div>

                  {/* Hint text */}
                  <motion.div
                    className="absolute bottom-4 left-1/2 transform -translate-x-1/2"
                    animate={{
                      y: [0, -5, 0],
                      opacity: [0.6, 1, 0.6],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                    }}
                  >
                    <p className="font-poppins text-rose-900/60 text-sm" style={{ fontWeight: 300 }}>
                      Click to open ✨
                    </p>
                  </motion.div>
                </motion.div>

                {/* Envelope flap */}
                <motion.div
                  className="absolute top-0 left-0 right-0 h-0 border-l-[50vw] border-l-transparent border-r-[50vw] border-r-transparent border-t-[120px] border-t-rose-300"
                  style={{
                    maxWidth: '100%',
                    borderLeftWidth: 'calc(50% - 2rem)',
                    borderRightWidth: 'calc(50% - 2rem)',
                    transformOrigin: 'top center',
                  }}
                />
              </motion.div>
            ) : (
              // Opened letter with paper unfold animation
              <motion.div
                className="relative"
                initial={{ rotateX: 90, opacity: 0 }}
                animate={{ rotateX: 0, opacity: 1 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                style={{ perspective: 1000 }}
              >
                <motion.div
                  className="bg-gradient-to-br from-amber-50 via-white to-rose-50 rounded-2xl shadow-2xl p-8 md:p-12 relative overflow-hidden"
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  style={{ transformOrigin: 'top' }}
                >
                  {/* Paper texture overlay */}
                  <div className="absolute inset-0 opacity-5" style={{
                    backgroundImage: 'url("data:image/svg+xml,%3Csvg width="100" height="100" xmlns="http://www.w3.org/2000/svg"%3E%3Cfilter id="noise"%3E%3CfeTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="4" /%3E%3C/filter%3E%3Crect width="100" height="100" filter="url(%23noise)" opacity="0.3"/%3E%3C/svg%3E")',
                  }} />

                  {/* Close button */}
                  <motion.button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleClose();
                    }}
                    className="absolute top-4 right-4 w-10 h-10 rounded-full bg-rose-100 hover:bg-rose-200 flex items-center justify-center text-rose-700 transition-colors z-20 cursor-pointer"
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    ✕
                  </motion.button>

                  {/* Letter content with staggered animation */}
                  <motion.div
                    className="relative z-10"
                    initial="hidden"
                    animate="visible"
                    variants={{
                      hidden: { opacity: 0 },
                      visible: {
                        opacity: 1,
                        transition: {
                          staggerChildren: 0.1,
                          delayChildren: 0.3,
                        },
                      },
                    }}
                  >
                    {/* Header decoration */}
                    <motion.div
                      className="flex justify-center mb-6"
                      variants={{
                        hidden: { opacity: 0, y: -20 },
                        visible: { opacity: 1, y: 0 },
                      }}
                    >
                      <div className="flex gap-2 text-2xl">
                        {['🌸', '💕', '🐱', '💕', '🌸'].map((emoji, i) => (
                          <motion.span
                            key={i}
                            animate={{
                              y: [0, -8, 0],
                              rotate: [0, 10, -10, 0],
                            }}
                            transition={{
                              duration: 2,
                              repeat: Infinity,
                              delay: i * 0.2,
                            }}
                          >
                            {emoji}
                          </motion.span>
                        ))}
                      </div>
                    </motion.div>

                    {/* Title */}
                    <motion.h2
                      className="font-playfair text-3xl md:text-4xl text-rose-900 text-center mb-6"
                      variants={{
                        hidden: { opacity: 0, y: 20 },
                        visible: { opacity: 1, y: 0 },
                      }}
                    >
                      For You, On Your Special Day
                    </motion.h2>

                    {/* Letter content */}
                    <motion.div
                      className="space-y-4 font-poppins text-rose-800/90 leading-relaxed text-base"
                      style={{ fontWeight: 300 }}
                      variants={{
                        hidden: { opacity: 0 },
                        visible: { opacity: 1 },
                      }}
                    >
                      <motion.p
                        className="text-base"
                        variants={{
                          hidden: { opacity: 0, x: -20 },
                          visible: { opacity: 1, x: 0 },
                        }}
                      >
                        Dear Birthday Girl,
                      </motion.p>

                      <motion.p
                        className="text-base"
                        variants={{
                          hidden: { opacity: 0, x: -20 },
                          visible: { opacity: 1, x: 0 },
                        }}
                      >
                        Today is special—not just because it's your birthday, but because the world 
                        gets to celebrate that you exist. You bring warmth without even trying, and you 
                        make people feel heard in a way that's rare and beautiful.
                      </motion.p>

                      <motion.p
                        className="text-base"
                        variants={{
                          hidden: { opacity: 0, x: -20 },
                          visible: { opacity: 1, x: 0 },
                        }}
                      >
                        I hope this new year of your life is filled with small joys and big dreams coming 
                        true. I hope you find time for yourself—for the things you love, for the people who 
                        really get you, and for moments that make you feel at peace.
                      </motion.p>

                      <motion.p
                        className="text-base"
                        variants={{
                          hidden: { opacity: 0, x: -20 },
                          visible: { opacity: 1, x: 0 },
                        }}
                      >
                        Thank you for being exactly who you are. Thank you for your laughter, your honesty, 
                        and all the little things you do that mean more than you probably realize. You deserve 
                        all the happiness you quietly give to others.
                      </motion.p>

                      <motion.p
                        className="text-base"
                        variants={{
                          hidden: { opacity: 0, x: -20 },
                          visible: { opacity: 1, x: 0 },
                        }}
                      >
                        Here's to another year of dancing to Gracie Abrams, zoning out into adorable daydreams, 
                        making people laugh with your unique humor, and just being the softest, kindest soul. 
                        May you always remember how loved you are.
                      </motion.p>

                      <motion.p
                        className="text-center font-playfair text-xl text-rose-700 mt-8"
                        variants={{
                          hidden: { opacity: 0, scale: 0.8 },
                          visible: { opacity: 1, scale: 1 },
                        }}
                      >
                        Happy Birthday! 🎂✨
                      </motion.p>
                    </motion.div>

                    {/* Bottom decoration */}
                    <motion.div
                      className="flex justify-center gap-3 mt-8"
                      variants={{
                        hidden: { opacity: 0, y: 20 },
                        visible: { opacity: 1, y: 0 },
                      }}
                    >
                      <CatPaw className="w-8 h-8 text-rose-300/40" />
                      <span className="text-rose-400 text-xl">~</span>
                      <CatPaw className="w-8 h-8 text-rose-300/40" />
                    </motion.div>
                  </motion.div>
                </motion.div>
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// Button component to trigger the letter popup
export const OpenLetterButton = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <motion.button
        onClick={() => setIsOpen(true)}
        className="group relative px-8 py-4 bg-gradient-to-r from-rose-400 to-pink-400 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden"
        whileHover={{ scale: 1.05, y: -2 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* Shimmer effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
          animate={{
            x: ['-200%', '200%'],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        <span className="relative flex items-center gap-2 font-poppins" style={{ fontWeight: 400 }}>
          <motion.span
            animate={{
              rotate: [0, 15, -15, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          >
            💌
          </motion.span>
          Open Your Letter
          <motion.span
            animate={{
              x: [0, 5, 0],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
            }}
          >
            ✨
          </motion.span>
        </span>

        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 rounded-full"
          animate={{
            boxShadow: [
              '0 0 0px rgba(251, 113, 133, 0)',
              '0 0 20px rgba(251, 113, 133, 0.5)',
              '0 0 0px rgba(251, 113, 133, 0)',
            ],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        />
      </motion.button>

      <LetterPopup isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
};