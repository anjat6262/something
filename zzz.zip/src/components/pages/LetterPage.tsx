import { motion } from 'motion/react';
import { Heart, Sparkles, Star } from 'lucide-react';

export const LetterPage = () => {
  return (
    <section className="relative py-20 px-6 overflow-hidden">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Floating decorative elements */}
          <motion.div
            className="absolute top-10 left-10 text-5xl opacity-20"
            animate={{ 
              y: [0, -20, 0],
              rotate: [0, 10, 0]
            }}
            transition={{ duration: 4, repeat: Infinity }}
          >
            ✨
          </motion.div>
          <motion.div
            className="absolute top-20 right-20 text-4xl opacity-20"
            animate={{ 
              y: [0, 20, 0],
              rotate: [0, -10, 0]
            }}
            transition={{ duration: 5, repeat: Infinity, delay: 0.5 }}
          >
            💫
          </motion.div>
          <motion.div
            className="absolute bottom-20 left-20 text-4xl opacity-20"
            animate={{ 
              y: [0, -15, 0],
              rotate: [0, 15, 0]
            }}
            transition={{ duration: 4.5, repeat: Infinity, delay: 1 }}
          >
            🌸
          </motion.div>

          {/* Header */}
          <div className="text-center mb-8 sm:mb-12 px-4">
            <motion.div
              className="inline-block mb-4"
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Heart className="w-10 h-10 sm:w-12 sm:h-12 text-rose-400 fill-rose-400" />
            </motion.div>
            <h2 className="font-playfair text-3xl sm:text-4xl md:text-5xl text-rose-900 mb-3">
              Before You Go
            </h2>
            <p className="font-poppins text-rose-700/70 text-sm sm:text-base" style={{ fontWeight: 300 }}>
              A few last words from my heart to yours
            </p>
          </div>

          {/* Letter Container - Elegant Card Style */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="relative"
          >
            {/* Glow effect */}
            <div className="absolute -inset-4 bg-gradient-to-br from-pink-200 via-rose-200 to-pink-200 rounded-[3rem] opacity-40 blur-2xl"></div>
            
            {/* Main card */}
            <div className="relative bg-gradient-to-br from-white via-pink-50/30 to-white rounded-[2.5rem] p-8 md:p-12 shadow-2xl border-4 border-white/80">
              
              {/* Inner border decoration */}
              <div className="absolute inset-4 border-2 border-pink-200/40 rounded-[2rem] pointer-events-none"></div>

              {/* Content */}
              <div className="relative z-10 space-y-6">
                
                {/* Opening */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <p className="font-poppins text-rose-900 text-lg md:text-xl leading-relaxed text-center" style={{ fontWeight: 400 }}>
                    Thank you for being <span className="font-playfair italic" style={{ fontWeight: 600 }}>you</span>.
                  </p>
                </motion.div>

                {/* Divider */}
                <motion.div
                  className="flex items-center justify-center gap-3 my-6"
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7 }}
                >
                  <Star className="w-4 h-4 text-pink-400" fill="currentColor" />
                  <div className="h-px w-16 bg-gradient-to-r from-transparent via-pink-300 to-transparent"></div>
                  <Sparkles className="w-5 h-5 text-rose-400" />
                  <div className="h-px w-16 bg-gradient-to-r from-transparent via-pink-300 to-transparent"></div>
                  <Star className="w-4 h-4 text-pink-400" fill="currentColor" />
                </motion.div>

                {/* Main message */}
                <motion.div
                  className="space-y-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 }}
                >
                  <p className="font-poppins text-rose-800/90 text-base md:text-lg leading-relaxed" style={{ fontWeight: 300 }}>
                    I made this website because I wanted you to have something special on your birthday. Something that reminds you of how much you matter—not just today, but every single day.
                  </p>
                  
                  <p className="font-poppins text-rose-800/90 text-base md:text-lg leading-relaxed" style={{ fontWeight: 300 }}>
                    You're not perfect, and that's okay. Nobody is. But you're <span className="text-rose-900" style={{ fontWeight: 600 }}>kind</span>, you're <span className="text-rose-900" style={{ fontWeight: 600 }}>thoughtful</span>, you're <span className="text-rose-900" style={{ fontWeight: 600 }}>strong</span>, and you're <span className="text-rose-900" style={{ fontWeight: 600 }}>trying</span>. That's more than enough.
                  </p>

                  <p className="font-poppins text-rose-800/90 text-base md:text-lg leading-relaxed" style={{ fontWeight: 300 }}>
                    Whenever you feel lost or doubt yourself, come back here. Read these pages again. Let them remind you of your worth, your strength, and all the reasons you deserve happiness.
                  </p>

                  <p className="font-poppins text-rose-800/90 text-base md:text-lg leading-relaxed mt-6" style={{ fontWeight: 300 }}>
                    One more thing... if you know who made this for you, I hope you can keep it between us. This is something I wanted to give quietly, just for you. I trust you with this. 💭
                  </p>
                </motion.div>

                {/* Divider */}
                <motion.div
                  className="flex items-center justify-center gap-3 my-6"
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 1.1 }}
                >
                  <div className="h-px w-20 bg-gradient-to-r from-transparent via-rose-300 to-transparent"></div>
                  <Heart className="w-5 h-5 text-pink-400" fill="currentColor" />
                  <div className="h-px w-20 bg-gradient-to-r from-transparent via-rose-300 to-transparent"></div>
                </motion.div>

                {/* Closing */}
                <motion.div
                  className="text-center space-y-3"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.3 }}
                >
                  <p className="font-poppins text-rose-700/80 text-base md:text-lg leading-relaxed" style={{ fontWeight: 300 }}>
                    I hope this little corner of the internet made you smile.
                  </p>
                  <p className="font-poppins text-rose-700/80 text-base md:text-lg leading-relaxed" style={{ fontWeight: 300 }}>
                    Thanks for taking the time to be here.
                  </p>
                  <p className="font-playfair text-xl md:text-2xl text-rose-900 italic mt-4" style={{ fontWeight: 500 }}>
                    Wishing you the happiest birthday! 🎂✨
                  </p>
                </motion.div>

                {/* Signature area */}
                <motion.div
                  className="mt-8 pt-6 border-t border-pink-200/50 text-right"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.5 }}
                >
                  <p className="font-poppins text-rose-600/70 text-sm italic" style={{ fontWeight: 300 }}>
                    With love and good vibes,
                  </p>
                  <p className="font-playfair text-lg text-rose-800 mt-1" style={{ fontWeight: 600 }}>
                    Your Friend 💕
                  </p>
                </motion.div>

                {/* Decorative elements at corners */}
                <div className="absolute top-6 left-6 text-3xl opacity-30">🌸</div>
                <div className="absolute top-6 right-6 text-3xl opacity-30">🌸</div>
                <div className="absolute bottom-6 left-6 text-3xl opacity-30">🦋</div>
                <div className="absolute bottom-6 right-6 text-3xl opacity-30">🦋</div>
              </div>
            </div>
          </motion.div>

          {/* Bottom decorative text */}
          <motion.div
            className="text-center mt-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.7 }}
          >
            <p className="font-poppins text-rose-500/60 text-sm italic" style={{ fontWeight: 300 }}>
              ✨ You can revisit this website anytime you need a reminder ✨
            </p>
          </motion.div>

          {/* Floating hearts animation */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-2xl opacity-20"
                style={{
                  left: `${10 + i * 15}%`,
                  bottom: '-10%'
                }}
                animate={{
                  y: [0, -800],
                  x: [0, (i % 2 ? 50 : -50)],
                  rotate: [0, 360],
                  opacity: [0, 0.3, 0]
                }}
                transition={{
                  duration: 8 + i,
                  repeat: Infinity,
                  delay: i * 1.5,
                  ease: "easeOut"
                }}
              >
                💖
              </motion.div>
            ))}
          </div>

          {/* Extra padding for navigation */}
          <div className="h-32"></div>
        </motion.div>
      </div>
    </section>
  );
};