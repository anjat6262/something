import { motion } from 'motion/react';
import { Heart, Sparkles, Gift } from 'lucide-react';
import { CatWithHeart, PlayfulCat } from '../CatIllustrations';

export const HeroPage = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 overflow-hidden">
      {/* Subtle gradient orbs */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div 
          className="absolute top-20 -right-20 w-96 h-96 bg-pink-200/20 rounded-full blur-3xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div 
          className="absolute -bottom-20 -left-20 w-96 h-96 bg-rose-200/20 rounded-full blur-3xl"
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.5, 0.3, 0.5] }}
          transition={{ duration: 8, repeat: Infinity, delay: 1 }}
        />
      </div>

      {/* Floating cat illustrations */}
      <motion.div 
        className="absolute top-32 right-16 text-pink-300/30 hidden md:block"
        animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
        transition={{ duration: 5, repeat: Infinity }}
      >
        <CatWithHeart className="w-20 h-20" />
      </motion.div>
      <motion.div 
        className="absolute bottom-32 left-16 text-pink-300/30 hidden md:block"
        animate={{ y: [0, -15, 0], rotate: [0, -5, 0] }}
        transition={{ duration: 6, repeat: Infinity, delay: 1 }}
      >
        <PlayfulCat className="w-16 h-16" />
      </motion.div>

      <div className="relative z-10 max-w-5xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <motion.div 
            className="inline-block mb-6"
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Sparkles className="w-12 h-12 text-pink-400 mx-auto" />
          </motion.div>
          
          <h1 className="font-playfair text-4xl sm:text-5xl md:text-7xl lg:text-8xl text-rose-900 mb-6 sm:mb-8 leading-tight px-4">
            Happy Birthday
          </h1>
          
          <p className="font-poppins text-base sm:text-lg md:text-xl text-rose-700/80 max-w-2xl mx-auto leading-relaxed mb-8 sm:mb-12 px-6" style={{ fontWeight: 300 }}>
            To the girl who brings light in the smallest moments. May your day be filled with warmth, gentle laughter, and all the sweet things you deserve.
          </p>

          <motion.div
            className="flex items-center justify-center gap-6 text-pink-400/60"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 2, repeat: Infinity }}>
              <Heart className="w-6 h-6" />
            </motion.div>
            <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 2, repeat: Infinity, delay: 0.3 }}>
              <Sparkles className="w-6 h-6" />
            </motion.div>
            <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 2, repeat: Infinity, delay: 0.6 }}>
              <Gift className="w-6 h-6" />
            </motion.div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll/Swipe hint */}
      <motion.div
        className="absolute bottom-24 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity, delay: 1 }}
      >
        <p className="font-poppins text-rose-400/60 text-sm mb-2" style={{ fontWeight: 300 }}>
          Swipe or use navigation below
        </p>
      </motion.div>
    </section>
  );
};