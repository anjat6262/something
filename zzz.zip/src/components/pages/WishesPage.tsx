import { motion } from 'motion/react';
import { SittingCat } from '../CatIllustrations';

interface Wish {
  text: string;
  icon: string;
}

interface WishesPageProps {
  wishes: Wish[];
}

export const WishesPage = ({ wishes }: WishesPageProps) => {
  return (
    <section className="relative py-20 px-6">
      <div className="max-w-5xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl sm:text-4xl md:text-5xl text-rose-900 mb-3 px-4">
              Wishes For You
            </h2>
            <p className="font-poppins text-rose-700/70 px-4" style={{ fontWeight: 300 }}>
              May all these come true ✨
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-16 px-4">
            {wishes.map((wish, index) => (
              <motion.div
                key={index}
                className="tilt-card"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <div className="bg-white/70 backdrop-blur-xl rounded-2xl p-5 sm:p-6 shadow-xl border border-rose-100/50 h-full flex flex-col items-center text-center group hover:shadow-2xl transition-shadow duration-500">
                  <motion.div 
                    className="text-3xl sm:text-4xl mb-3 sm:mb-4"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                  >
                    {wish.icon}
                  </motion.div>
                  <p className="font-poppins text-rose-800 text-sm sm:text-base" style={{ fontWeight: 300 }}>
                    {wish.text}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Footer section */}
          <motion.div
            className="text-center pt-8 pb-32"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <motion.div 
              className="flex justify-center gap-6 mb-6"
            >
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                >
                  <SittingCat className="w-10 h-10 text-pink-300" />
                </motion.div>
              ))}
            </motion.div>
            
            <p className="font-poppins text-rose-700/70 italic text-lg" style={{ fontWeight: 300 }}>
              May today be a reason for you to smile a little longer 💕
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};