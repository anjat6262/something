import { motion } from 'motion/react';
import { useState } from 'react';
import { Gamepad2, Puzzle, Brain, Gift } from 'lucide-react';
import { PuzzleGame } from '../games/PuzzleGame';
import { FactQuiz } from '../games/FactQuiz';
import { SurpriseGifts } from '../games/SurpriseGifts';

type GameType = 'menu' | 'puzzle' | 'quiz' | 'gifts';

export const MiniGamesPage = () => {
  const [currentGame, setCurrentGame] = useState<GameType>('menu');

  const games = [
    {
      id: 'puzzle' as GameType,
      title: 'Puzzle Her Smile',
      description: 'Put the pieces together!',
      icon: Puzzle,
      color: 'from-pink-400 to-rose-400',
    },
    {
      id: 'quiz' as GameType,
      title: 'Gracie Abrams Quiz',
      description: 'Who knows her better?',
      icon: Brain,
      color: 'from-rose-400 to-pink-500',
    },
    {
      id: 'gifts' as GameType,
      title: 'Surprise Gifts',
      description: 'Click to reveal messages!',
      icon: Gift,
      color: 'from-pink-500 to-rose-500',
    },
  ];

  const renderGame = () => {
    switch (currentGame) {
      case 'puzzle':
        return (
          <PuzzleGame imageUrl="https://images.unsplash.com/photo-1545311630-51ea4a4c84de?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMGhhcHB5JTIwcG9ydHJhaXR8ZW58MXx8fHwxNzY0NzQxMjE2fDA&ixlib=rb-4.1.0&q=80&w=1080" />
        );
      case 'quiz':
        return <FactQuiz />;
      case 'gifts':
        return <SurpriseGifts />;
      default:
        return null;
    }
  };

  return (
    <section className="relative py-20 px-6">
      <div className="max-w-5xl mx-auto w-full">
        {currentGame === 'menu' ? (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-center mb-12 px-4">
              <motion.div
                className="inline-block mb-4"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Gamepad2 className="w-12 h-12 sm:w-16 sm:h-16 text-pink-400 mx-auto" />
              </motion.div>
              <h2 className="font-playfair text-3xl sm:text-4xl md:text-5xl text-rose-900 mb-3">
                Let's Play Some Games!
              </h2>
              <p className="font-poppins text-rose-700/70 text-sm sm:text-base" style={{ fontWeight: 300 }}>
                Choose a game to make this celebration more fun! 🎮
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 px-4">
              {games.map((game, index) => {
                const Icon = game.icon;
                return (
                  <motion.button
                    key={game.id}
                    onClick={() => setCurrentGame(game.id)}
                    className="group relative touch-manipulation"
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.15 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <div className={`bg-gradient-to-br ${game.color} rounded-3xl p-6 sm:p-8 shadow-xl border border-white/50 h-full flex flex-col items-center text-center text-white relative overflow-hidden min-h-[200px]`}>
                      {/* Background decoration */}
                      <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.4 }}
                        className="relative z-10"
                      >
                        <Icon className="w-16 h-16 mb-4" />
                      </motion.div>

                      <h3 className="font-playfair text-2xl mb-2 relative z-10">
                        {game.title}
                      </h3>
                      <p className="font-poppins text-sm opacity-90 relative z-10" style={{ fontWeight: 300 }}>
                        {game.description}
                      </p>

                      {/* Hover arrow */}
                      <motion.div
                        className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100"
                        initial={{ x: -10 }}
                        whileHover={{ x: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <span className="text-2xl">→</span>
                      </motion.div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.5 }}
          >
            {/* Back button */}
            <motion.button
              onClick={() => setCurrentGame('menu')}
              className="mb-8 inline-flex items-center gap-2 px-6 py-3 bg-white/70 backdrop-blur-xl rounded-full shadow-lg border border-rose-100/50 text-rose-700 font-poppins hover:shadow-xl transition-all duration-300"
              style={{ fontWeight: 500 }}
              whileHover={{ scale: 1.05, x: -5 }}
              whileTap={{ scale: 0.95 }}
            >
              <span>← Back to Menu</span>
            </motion.button>

            {/* Game Content */}
            <div className="pb-32">
              {renderGame()}
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};