import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { Heart, Sparkles, Star } from 'lucide-react';

interface PolaroidCard {
  id: number;
  message: string;
  emoji: string;
  rotation: number;
  x: number;
  y: number;
  delay: number;
}

export const GoodbyePage = () => {
  const [showConfetti, setShowConfetti] = useState(true);
  const [revealedCards, setRevealedCards] = useState<number[]>([]);
  const [showFinalMessage, setShowFinalMessage] = useState(false);

  const polaroidCards: PolaroidCard[] = [
    {
      id: 1,
      message: "You made someone's day just by being yourself",
      emoji: "💫",
      rotation: -8,
      x: -200,
      y: -100,
      delay: 0.3
    },
    {
      id: 2,
      message: "The world is brighter with you in it",
      emoji: "🌟",
      rotation: 5,
      x: 200,
      y: -80,
      delay: 0.6
    },
    {
      id: 3,
      message: "Never stop being this amazing",
      emoji: "✨",
      rotation: -12,
      x: -180,
      y: 100,
      delay: 0.9
    },
    {
      id: 4,
      message: "Your smile is contagious",
      emoji: "😊",
      rotation: 10,
      x: 180,
      y: 120,
      delay: 1.2
    },
    {
      id: 5,
      message: "Come back whenever you need a reminder",
      emoji: "💝",
      rotation: -5,
      x: 0,
      y: 180,
      delay: 1.5
    }
  ];

  const confettiPieces = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    delay: Math.random() * 2,
    duration: 3 + Math.random() * 2,
    rotation: Math.random() * 360,
    color: ['#fda4af', '#fb7185', '#f472b6', '#ec4899', '#fbbf24', '#fcd34d'][Math.floor(Math.random() * 6)]
  }));

  const sparkles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 3,
    duration: 2 + Math.random() * 2
  }));

  useEffect(() => {
    // Auto-reveal cards one by one
    polaroidCards.forEach((card) => {
      setTimeout(() => {
        setRevealedCards((prev) => [...prev, card.id]);
      }, card.delay * 1000);
    });

    // Show final message after all cards
    setTimeout(() => {
      setShowFinalMessage(true);
    }, 3000);

    // Stop confetti after a while
    setTimeout(() => {
      setShowConfetti(false);
    }, 5000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCardClick = (cardId: number) => {
    // Add sparkle effect or scale animation on click
    const card = document.getElementById(`polaroid-${cardId}`);
    if (card) {
      card.style.transform = `scale(1.1) rotate(${Math.random() * 20 - 10}deg)`;
      setTimeout(() => {
        card.style.transform = '';
      }, 300);
    }
  };

  return (
    <section className="relative min-h-screen py-20 px-6 overflow-hidden flex items-center justify-center">
      {/* Animated gradient background */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-rose-100 via-pink-100 to-rose-200"
        animate={{
          background: [
            'linear-gradient(to bottom right, #ffe4e6, #fce7f3, #fecdd3)',
            'linear-gradient(to bottom right, #fce7f3, #fecdd3, #ffe4e6)',
            'linear-gradient(to bottom right, #fecdd3, #ffe4e6, #fce7f3)',
          ]
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
      />

      {/* Confetti */}
      <AnimatePresence>
        {showConfetti && confettiPieces.map((piece) => (
          <motion.div
            key={piece.id}
            className="absolute w-3 h-3 rounded-full"
            style={{
              backgroundColor: piece.color,
              left: `${piece.x}%`,
              top: '-10%'
            }}
            initial={{ y: 0, opacity: 1, rotate: 0 }}
            animate={{
              y: '120vh',
              opacity: [1, 1, 0],
              rotate: piece.rotation
            }}
            exit={{ opacity: 0 }}
            transition={{
              duration: piece.duration,
              delay: piece.delay,
              ease: 'linear'
            }}
          />
        ))}
      </AnimatePresence>

      {/* Floating sparkles */}
      {sparkles.map((sparkle) => (
        <motion.div
          key={sparkle.id}
          className="absolute"
          style={{
            left: `${sparkle.x}%`,
            top: `${sparkle.y}%`
          }}
          animate={{
            scale: [0, 1, 0],
            opacity: [0, 1, 0],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: sparkle.duration,
            delay: sparkle.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <Sparkles className="w-4 h-4 text-yellow-400" />
        </motion.div>
      ))}

      {/* Main content container */}
      <div className="relative z-10 max-w-6xl mx-auto w-full">
        {/* Center main goodbye message */}
        <motion.div
          className="text-center mb-12 sm:mb-20 px-4"
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.4, 0, 0.2, 1] }}
        >
          <motion.div
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <h2 className="font-playfair text-3xl sm:text-4xl md:text-6xl lg:text-7xl text-rose-900 mb-4 sm:mb-6">
              Until We Meet Again
            </h2>
          </motion.div>
          
          <motion.p
            className="font-poppins text-rose-700/80 text-base sm:text-lg md:text-xl max-w-2xl mx-auto px-4"
            style={{ fontWeight: 300 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            This isn't goodbye forever—just see you later.
            <br />
            You can always come back here whenever you need it.
          </motion.p>

          {/* Animated hearts */}
          <motion.div
            className="flex justify-center gap-4 mt-6 sm:mt-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{
                  y: [0, -20, 0],
                  scale: [1, 1.2, 1]
                }}
                transition={{
                  duration: 2,
                  delay: i * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Heart className="w-5 h-5 sm:w-6 sm:h-6 text-rose-400 fill-rose-400" />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Floating polaroid cards */}
        <div className="relative h-[400px] hidden md:block">
          {polaroidCards.map((card) => (
            <AnimatePresence key={card.id}>
              {revealedCards.includes(card.id) && (
                <motion.div
                  id={`polaroid-${card.id}`}
                  className="absolute left-1/2 top-1/2 cursor-pointer"
                  initial={{
                    opacity: 0,
                    scale: 0,
                    x: 0,
                    y: 0,
                    rotate: 0
                  }}
                  animate={{
                    opacity: 1,
                    scale: 1,
                    x: card.x,
                    y: card.y,
                    rotate: card.rotation
                  }}
                  whileHover={{
                    scale: 1.1,
                    rotate: 0,
                    zIndex: 50,
                    transition: { duration: 0.2 }
                  }}
                  transition={{
                    duration: 0.8,
                    ease: [0.4, 0, 0.2, 1]
                  }}
                  onClick={() => handleCardClick(card.id)}
                  style={{
                    transition: 'transform 0.3s ease-out'
                  }}
                >
                  {/* Polaroid frame */}
                  <div className="bg-white p-4 pb-16 shadow-2xl rounded-lg transform-gpu">
                    <div className="bg-gradient-to-br from-rose-50 to-pink-50 p-6 rounded">
                      <div className="text-5xl mb-4 text-center">
                        {card.emoji}
                      </div>
                      <p className="font-poppins text-rose-800 text-center text-sm" style={{ fontWeight: 400 }}>
                        {card.message}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          ))}
        </div>

        {/* Mobile-friendly cards grid */}
        <div className="grid grid-cols-1 gap-4 md:hidden mt-12">
          {polaroidCards.map((card) => (
            <AnimatePresence key={card.id}>
              {revealedCards.includes(card.id) && (
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                  className="bg-white p-4 pb-12 shadow-xl rounded-lg"
                >
                  <div className="bg-gradient-to-br from-rose-50 to-pink-50 p-6 rounded">
                    <div className="text-4xl mb-3 text-center">
                      {card.emoji}
                    </div>
                    <p className="font-poppins text-rose-800 text-center" style={{ fontWeight: 400 }}>
                      {card.message}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          ))}
        </div>

        {/* Final message */}
        <AnimatePresence>
          {showFinalMessage && (
            <motion.div
              className="text-center mt-20 space-y-6"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              <motion.div
                className="inline-flex items-center gap-3 bg-white/80 backdrop-blur-xl px-8 py-4 rounded-full shadow-xl border border-rose-100"
                animate={{
                  boxShadow: [
                    '0 20px 60px rgba(251, 113, 133, 0.2)',
                    '0 20px 80px rgba(251, 113, 133, 0.4)',
                    '0 20px 60px rgba(251, 113, 133, 0.2)',
                  ]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <p className="font-playfair text-rose-900 text-xl md:text-2xl" style={{ fontWeight: 500 }}>
                  You're loved, you're valued, you're enough
                </p>
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
              </motion.div>

              <motion.p
                className="font-poppins text-rose-600 italic text-base"
                style={{ fontWeight: 300 }}
                animate={{
                  opacity: [0.7, 1, 0.7]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                Take care, birthday girl! 💕✨🎂
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom decorative cats */}
        <motion.div
          className="flex justify-center gap-8 mt-20"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2, duration: 1 }}
        >
          {['🐱', '🐈', '🐱'].map((cat, i) => (
            <motion.div
              key={i}
              className="text-4xl opacity-30"
              animate={{
                rotate: [0, 10, -10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{
                duration: 3,
                delay: i * 0.4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              {cat}
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};