import { motion, AnimatePresence } from 'motion/react';
import { useState, useRef, useEffect } from 'react';
import { Camera, CameraOff, Sparkles, Heart, Star, Smile, Upload, X } from 'lucide-react';

interface Particle {
  id: number;
  x: number;
  y: number;
  emoji: string;
  rotation: number;
  speed: number;
}

interface Message {
  id: number;
  text: string;
  x: number;
  y: number;
  delay: number;
}

const birthdayMessages = [
  "Happy Birthday! 🎉",
  "You're Beautiful! ✨",
  "Shine Bright! 🌟",
  "Stay Amazing! 💖",
  "You're Loved! 💕",
  "Dream Big! 🌸",
  "Be Happy! 😊",
  "You're Special! 🎀"
];

export const MagicMirrorPage = () => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [showEffects, setShowEffects] = useState(false);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Start camera
  const startCamera = async () => {
    setCameraError(null);
    setUploadedImage(null); // Clear uploaded image when starting camera
    
    try {
      // Check if mediaDevices is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Camera not supported on this device. Upload a photo instead! 📸');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        // Wait for video to be ready
        await videoRef.current.play();
        streamRef.current = stream;
        setIsCameraActive(true);
        
        // Auto-trigger effects after 2 seconds
        setTimeout(() => {
          triggerEffects();
        }, 2000);
      }
    } catch (error) {
      console.error('Camera error:', error);
      // Provide helpful error messages
      if (error instanceof DOMException) {
        if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
          setCameraError('📷 Camera permission denied. Please allow camera access or upload a photo instead!');
        } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
          setCameraError('📷 No camera found. Upload a photo instead!');
        } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
          setCameraError('📷 Camera is busy. Close other apps using the camera or upload a photo!');
        } else {
          setCameraError('📷 Cannot access camera. Upload a photo instead!');
        }
      } else {
        setCameraError('📷 Camera error. Upload a photo instead!');
      }
    }
  };

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target?.result as string);
        setIsCameraActive(true);
        setCameraError(null);
        
        // Auto-trigger effects after 1 second
        setTimeout(() => {
          triggerEffects();
        }, 1000);
      };
      reader.readAsDataURL(file);
    }
  };

  // Trigger upload
  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setShowEffects(false);
    setParticles([]);
    setMessages([]);
    setUploadedImage(null);
    setCameraError(null);
  };

  // Trigger magical effects
  const triggerEffects = () => {
    setShowEffects(true);
    
    // Generate particles (confetti, balloons, flowers)
    const particleEmojis = ['🎉', '🎊', '✨', '💖', '🌸', '🌺', '🎀', '💕', '⭐', '🌟', '🎈', '🦋'];
    const newParticles: Particle[] = Array.from({ length: 30 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 100,
      y: -10,
      emoji: particleEmojis[Math.floor(Math.random() * particleEmojis.length)],
      rotation: Math.random() * 360,
      speed: 2 + Math.random() * 3
    }));
    setParticles(newParticles);

    // Generate floating messages around the frame
    const messagePositions = [
      { x: 10, y: 20 },
      { x: 70, y: 15 },
      { x: 5, y: 50 },
      { x: 75, y: 45 },
      { x: 15, y: 80 },
      { x: 65, y: 75 },
      { x: 40, y: 10 },
      { x: 45, y: 85 }
    ];

    const newMessages: Message[] = birthdayMessages.map((text, i) => ({
      id: i,
      text,
      x: messagePositions[i].x,
      y: messagePositions[i].y,
      delay: i * 0.2
    }));
    setMessages(newMessages);

    // Clear particles after animation
    setTimeout(() => {
      setParticles([]);
    }, 5000);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <section className="relative py-20 px-6 overflow-hidden">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              className="inline-block mb-4"
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="w-16 h-16 text-pink-400 mx-auto" />
            </motion.div>
            <h2 className="font-playfair text-3xl md:text-4xl lg:text-5xl text-rose-900 mb-3">
              Magic Mirror 🪞
            </h2>
            <p className="font-poppins text-rose-700/70 mb-2" style={{ fontWeight: 300 }}>
              Look into the mirror and let the magic surprise you!
            </p>
          </div>

          {/* Magic Mirror Container */}
          <div className="relative">
            {/* Decorative Frame */}
            <div className="absolute -inset-4 md:-inset-8 bg-gradient-to-br from-rose-200 via-pink-200 to-rose-200 rounded-[2rem] md:rounded-[3rem] opacity-50 blur-xl"></div>
            
            <div className="relative bg-gradient-to-br from-rose-100 via-pink-50 to-rose-100 rounded-3xl md:rounded-[2.5rem] p-4 md:p-8 shadow-2xl border-8 border-white/80">
              {/* Inner decorative border */}
              <div className="absolute inset-2 md:inset-4 border-4 border-pink-200/50 rounded-2xl md:rounded-[2rem] pointer-events-none"></div>
              
              {/* Corner ornaments */}
              <div className="absolute top-4 left-4 text-3xl md:text-4xl">🌸</div>
              <div className="absolute top-4 right-4 text-3xl md:text-4xl">🌸</div>
              <div className="absolute bottom-4 left-4 text-3xl md:text-4xl">🦋</div>
              <div className="absolute bottom-4 right-4 text-3xl md:text-4xl">🦋</div>

              {/* Mirror/Camera Display */}
              <div className="relative aspect-[3/4] md:aspect-[4/3] bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl overflow-hidden">
                {!isCameraActive ? (
                  /* Inactive State */
                  <motion.div
                    className="absolute inset-0 flex flex-col items-center justify-center"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <motion.div
                      className="text-6xl md:text-8xl mb-6"
                      animate={{ 
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0]
                      }}
                      transition={{ duration: 3, repeat: Infinity }}
                    >
                      🪞
                    </motion.div>
                    <h3 className="font-playfair text-2xl md:text-3xl text-white mb-4 text-center px-6">
                      The Magic Awaits...
                    </h3>
                    <p className="font-poppins text-white/70 text-center mb-8 px-6 text-sm md:text-base" style={{ fontWeight: 300 }}>
                      Activate the mirror to see your birthday magic!
                    </p>
                    
                    {/* Error message if camera denied */}
                    {cameraError && (
                      <motion.div
                        className="bg-rose-100 border-2 border-rose-300 rounded-2xl px-6 py-3 mb-4 mx-6"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                      >
                        <p className="font-poppins text-rose-700 text-sm text-center" style={{ fontWeight: 500 }}>
                          {cameraError}
                        </p>
                      </motion.div>
                    )}

                    <div className="flex flex-col sm:flex-row gap-3">
                      <button
                        onClick={startCamera}
                        className="px-8 py-4 bg-gradient-to-r from-pink-400 to-rose-400 text-white rounded-full font-poppins flex items-center justify-center gap-3 hover:shadow-2xl hover:scale-105 transition-all duration-300"
                        style={{ fontWeight: 600 }}
                      >
                        <Camera className="w-5 h-5" />
                        Use Camera
                      </button>
                      <button
                        onClick={triggerUpload}
                        className="px-8 py-4 bg-gradient-to-r from-rose-400 to-pink-400 text-white rounded-full font-poppins flex items-center justify-center gap-3 hover:shadow-2xl hover:scale-105 transition-all duration-300"
                        style={{ fontWeight: 600 }}
                      >
                        <Upload className="w-5 h-5" />
                        Upload Photo
                      </button>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                  </motion.div>
                ) : (
                  /* Active Camera State */
                  <>
                    {/* Video Feed or Uploaded Image */}
                    {uploadedImage ? (
                      <img
                        src={uploadedImage}
                        alt="Uploaded"
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    ) : (
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]"
                      />
                    )}

                    {/* Magical Overlay Effects */}
                    <div className="absolute inset-0 pointer-events-none">
                      {/* Sparkle border effect */}
                      <motion.div
                        className="absolute inset-0 border-4 border-pink-300/50 rounded-2xl"
                        animate={{ 
                          boxShadow: [
                            '0 0 20px rgba(244, 114, 182, 0.5)',
                            '0 0 40px rgba(244, 114, 182, 0.8)',
                            '0 0 20px rgba(244, 114, 182, 0.5)'
                          ]
                        }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />

                      {/* Floating Messages */}
                      <AnimatePresence>
                        {showEffects && messages.map((message) => (
                          <motion.div
                            key={message.id}
                            className="absolute font-poppins text-white text-xs md:text-sm px-3 py-1.5 md:px-4 md:py-2 bg-gradient-to-r from-pink-400/90 to-rose-400/90 rounded-full backdrop-blur-sm shadow-lg whitespace-nowrap"
                            style={{ 
                              left: `${message.x}%`, 
                              top: `${message.y}%`,
                              fontWeight: 600,
                              transform: 'translate(-50%, -50%)'
                            }}
                            initial={{ scale: 0, opacity: 0 }}
                            animate={{ 
                              scale: [0, 1.1, 1],
                              opacity: [0, 1, 1],
                              y: [0, -5, 0]
                            }}
                            exit={{ scale: 0, opacity: 0 }}
                            transition={{ 
                              delay: message.delay,
                              duration: 0.5,
                              y: {
                                duration: 2,
                                repeat: Infinity,
                                ease: "easeInOut"
                              }
                            }}
                          >
                            {message.text}
                          </motion.div>
                        ))}
                      </AnimatePresence>

                      {/* Falling Particles */}
                      <AnimatePresence>
                        {particles.map((particle) => (
                          <motion.div
                            key={particle.id}
                            className="absolute text-2xl md:text-4xl"
                            style={{ left: `${particle.x}%`, top: `${particle.y}%` }}
                            initial={{ y: -50, opacity: 1, rotate: particle.rotation }}
                            animate={{ 
                              y: '120vh',
                              rotate: particle.rotation + 720,
                              opacity: [1, 1, 0.5, 0]
                            }}
                            exit={{ opacity: 0 }}
                            transition={{ 
                              duration: particle.speed,
                              ease: "linear"
                            }}
                          >
                            {particle.emoji}
                          </motion.div>
                        ))}
                      </AnimatePresence>

                      {/* Center Heart Pulse */}
                      {showEffects && (
                        <motion.div
                          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
                          initial={{ scale: 0 }}
                          animate={{ scale: [0, 2, 0] }}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          <Heart className="w-20 h-20 text-pink-300/30" fill="currentColor" />
                        </motion.div>
                      )}
                    </div>

                    {/* Control Buttons */}
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-3 z-10">
                      <motion.button
                        onClick={triggerEffects}
                        className="px-6 py-3 bg-gradient-to-r from-pink-400 to-rose-400 text-white rounded-full font-poppins flex items-center gap-2 hover:shadow-xl transition-all duration-300"
                        style={{ fontWeight: 600 }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Smile className="w-5 h-5" />
                        <span className="hidden sm:inline">Magic!</span>
                      </motion.button>
                      
                      <motion.button
                        onClick={stopCamera}
                        className="px-6 py-3 bg-white/90 backdrop-blur-sm text-rose-600 rounded-full font-poppins flex items-center gap-2 hover:shadow-xl transition-all duration-300"
                        style={{ fontWeight: 600 }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <CameraOff className="w-5 h-5" />
                        <span className="hidden sm:inline">Close</span>
                      </motion.button>
                    </div>
                  </>
                )}
              </div>

              {/* Instructions */}
              {isCameraActive && (
                <motion.div
                  className="mt-6 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <p className="font-poppins text-rose-700 text-sm md:text-base mb-2" style={{ fontWeight: 500 }}>
                    ✨ Tap "Magic!" button to trigger birthday effects! ✨
                  </p>
                  <p className="font-poppins text-rose-600/70 text-xs md:text-sm" style={{ fontWeight: 300 }}>
                    The mirror sees your beauty and celebrates you! 💖
                  </p>
                </motion.div>
              )}
            </div>
          </div>

          {/* Info Cards */}
          {!isCameraActive && (
            <motion.div
              className="grid md:grid-cols-3 gap-4 mt-8"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center">
                <div className="text-4xl mb-3">📸</div>
                <h4 className="font-poppins text-rose-800 mb-2" style={{ fontWeight: 600 }}>
                  Selfie Time
                </h4>
                <p className="font-poppins text-rose-600/70 text-sm" style={{ fontWeight: 300 }}>
                  See yourself in the magic mirror
                </p>
              </div>

              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center">
                <div className="text-4xl mb-3">🎉</div>
                <h4 className="font-poppins text-rose-800 mb-2" style={{ fontWeight: 600 }}>
                  Birthday Magic
                </h4>
                <p className="font-poppins text-rose-600/70 text-sm" style={{ fontWeight: 300 }}>
                  Messages and confetti appear
                </p>
              </div>

              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center">
                <div className="text-4xl mb-3">✨</div>
                <h4 className="font-poppins text-rose-800 mb-2" style={{ fontWeight: 600 }}>
                  Celebrate You
                </h4>
                <p className="font-poppins text-rose-600/70 text-sm" style={{ fontWeight: 300 }}>
                  Because you're special!
                </p>
              </div>
            </motion.div>
          )}

          {/* Extra padding for navigation */}
          <div className="h-32"></div>
        </motion.div>
      </div>
    </section>
  );
};