import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { ChevronLeft, ChevronRight, BookOpen, Heart } from 'lucide-react';

interface ScrapbookPage {
  id: number;
  title: string;
  date: string;
  memory: string;
  decorations: string[];
  color: string;
  textColor: string;
}

const scrapbookPages: ScrapbookPage[] = [
  {
    id: 1,
    title: "You Are Enough",
    date: "A reminder you need",
    memory: "Sometimes you doubt yourself, but let me tell you—you are more than enough. You don't need to be perfect. You don't need to have it all figured out. Just being you is already amazing.",
    decorations: ["🌸", "✨", "💫"],
    color: "from-pink-50 to-rose-100",
    textColor: "text-rose-900"
  },
  {
    id: 2,
    title: "Your Strength",
    date: "Never forget this",
    memory: "You've been through so much and you're still here, still fighting, still shining. That takes real strength. Even on your hard days, remember how far you've come. You're stronger than you think.",
    decorations: ["💪", "🌟", "🔥"],
    color: "from-rose-50 to-pink-100",
    textColor: "text-pink-900"
  },
  {
    id: 3,
    title: "Chase Your Dreams",
    date: "No limits",
    memory: "Don't let fear or doubt hold you back. Your dreams are valid and you deserve to chase them. Take that leap, try that thing, go for it! The world needs what only you can offer. Believe in yourself.",
    decorations: ["🚀", "🌈", "⭐"],
    color: "from-pink-50 to-rose-100",
    textColor: "text-rose-900"
  },
  {
    id: 4,
    title: "It's Okay to Rest",
    date: "Be gentle with yourself",
    memory: "You don't always have to be productive or 'on'. It's okay to take breaks, to rest, to just exist without achieving anything. Self-care isn't selfish. You're allowed to prioritize your peace.",
    decorations: ["🌙", "☕", "🫧"],
    color: "from-rose-50 to-pink-100",
    textColor: "text-pink-900"
  },
  {
    id: 5,
    title: "Your Vibe is Contagious",
    date: "Keep shining",
    memory: "Your energy, your smile, the way you light up when you talk about things you love—it's infectious. You make spaces better just by being in them. Never dim your light for anyone. Keep being unapologetically you.",
    decorations: ["✨", "💖", "🌺"],
    color: "from-pink-50 to-rose-100",
    textColor: "text-rose-900"
  },
  {
    id: 6,
    title: "This Year is Yours",
    date: "Happy Birthday!",
    memory: "This is your year to glow, to grow, to achieve, to heal, to thrive. Whatever you want it to be. Don't compare your journey to anyone else's. You're exactly where you need to be. Here's to another year of being the incredible person you are! 🎂🎉",
    decorations: ["🎉", "🎈", "✨"],
    color: "from-rose-50 to-pink-100",
    textColor: "text-pink-900"
  }
];

export const DigitalScrapbookPage = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const [flipDirection, setFlipDirection] = useState<'forward' | 'backward'>('forward');
  const [hasStartedReading, setHasStartedReading] = useState(false);

  const totalPages = scrapbookPages.length;

  const nextPage = () => {
    if (currentPage < totalPages - 1) {
      setFlipDirection('forward');
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      setFlipDirection('backward');
      setCurrentPage(currentPage - 1);
    }
  };

  const page = scrapbookPages[currentPage];

  return (
    <section className="relative py-20 px-6">
      {/* Intro Modal Overlay */}
      <AnimatePresence>
        {!hasStartedReading && (
          <motion.div
            className="fixed inset-0 z-[200] flex items-center justify-center px-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            {/* Backdrop */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-rose-900/90 via-pink-900/90 to-rose-900/90 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />

            {/* Modal Content */}
            <motion.div
              className="relative z-10 max-w-lg w-full bg-gradient-to-br from-rose-50 to-pink-50 rounded-3xl shadow-2xl overflow-hidden"
              initial={{ scale: 0.8, y: 50, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ 
                type: "spring",
                stiffness: 100,
                damping: 20
              }}
            >
              {/* Decorative elements */}
              <div className="absolute top-0 left-0 w-32 h-32 bg-rose-200/30 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 right-0 w-40 h-40 bg-pink-200/30 rounded-full blur-3xl"></div>

              <div className="relative p-8 md:p-10">
                {/* Icon */}
                <motion.div
                  className="flex justify-center mb-6"
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ 
                    delay: 0.2,
                    type: "spring",
                    stiffness: 150,
                    damping: 15
                  }}
                >
                  <div className="relative">
                    <motion.div
                      className="absolute inset-0 bg-rose-300/40 rounded-full blur-xl"
                      animate={{ 
                        scale: [1, 1.2, 1],
                        opacity: [0.5, 0.8, 0.5]
                      }}
                      transition={{ 
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    />
                    <BookOpen className="w-20 h-20 text-rose-500 relative z-10" strokeWidth={1.5} />
                  </div>
                </motion.div>

                {/* Title */}
                <motion.h3
                  className="font-playfair text-3xl md:text-4xl text-rose-900 text-center mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  You Have {totalPages} Reminders
                </motion.h3>

                {/* Message */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="space-y-4 mb-8"
                >
                  <p className="font-poppins text-rose-700 text-center leading-relaxed" style={{ fontWeight: 400 }}>
                    I wrote these especially for you. Each one is a little reminder of things I hope you never forget.
                  </p>
                  
                  <div className="bg-white/50 rounded-2xl p-4 border-2 border-rose-200/50">
                    <p className="font-poppins text-rose-600 text-center text-sm italic" style={{ fontWeight: 300 }}>
                      💭 Take your time reading them. Let each message sink in. You deserve to hear all of this.
                    </p>
                  </div>
                </motion.div>

                {/* Decorative hearts */}
                <motion.div
                  className="flex justify-center gap-3 mb-8 text-2xl"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  {['💕', '✨', '💖', '✨', '💕'].map((emoji, i) => (
                    <motion.span
                      key={i}
                      animate={{ 
                        y: [0, -8, 0],
                        rotate: [0, 10, -10, 0]
                      }}
                      transition={{ 
                        duration: 2,
                        repeat: Infinity,
                        delay: i * 0.2
                      }}
                    >
                      {emoji}
                    </motion.span>
                  ))}
                </motion.div>

                {/* Start Button */}
                <motion.button
                  onClick={() => setHasStartedReading(true)}
                  className="w-full bg-gradient-to-r from-rose-400 via-pink-400 to-rose-400 text-white py-4 px-8 rounded-full font-poppins transition-all duration-300 hover:shadow-2xl hover:scale-105 relative overflow-hidden group"
                  style={{ fontWeight: 600 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {/* Shine effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                    initial={{ x: '-100%' }}
                    animate={{ x: '200%' }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      repeatDelay: 1,
                      ease: "easeInOut"
                    }}
                  />
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    <Heart className="w-5 h-5" fill="currentColor" />
                    Start Reading
                    <Heart className="w-5 h-5" fill="currentColor" />
                  </span>
                </motion.button>

                {/* Small note */}
                <motion.p
                  className="font-poppins text-rose-500/60 text-center text-xs mt-4"
                  style={{ fontWeight: 300 }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                >
                  Click when you're ready ✨
                </motion.p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-5xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Header */}
          <div className="text-center mb-12">
            <motion.div
              className="inline-block mb-4"
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <BookOpen className="w-16 h-16 text-pink-400 mx-auto" />
            </motion.div>
            <h2 className="font-playfair text-3xl md:text-4xl lg:text-5xl text-rose-900 mb-3">
              Reminders For You 💌
            </h2>
            <p className="font-poppins text-rose-700/70 mb-2" style={{ fontWeight: 300 }}>
              Words you need to hear today and every day
            </p>
            <div className="flex items-center justify-center gap-2 text-rose-600">
              <span className="font-poppins" style={{ fontWeight: 500 }}>
                Page {currentPage + 1} of {totalPages}
              </span>
            </div>
          </div>

          {/* Scrapbook Container */}
          <div className="relative perspective-[2000px]">
            {/* Book Shadow */}
            <div className="absolute -inset-4 bg-gradient-to-br from-rose-300/30 to-pink-300/30 rounded-3xl blur-2xl"></div>

            {/* Book Spine & Cover Effect */}
            <div className="relative bg-gradient-to-r from-rose-200 via-pink-100 to-rose-200 rounded-3xl p-1 shadow-2xl">
              
              {/* Main Page Container */}
              <div className="relative bg-white rounded-3xl overflow-hidden min-h-[500px] md:min-h-[600px]">
                
                {/* Decorative corners */}
                <div className="absolute top-0 left-0 w-24 h-24 opacity-20">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path d="M 0 0 L 100 0 L 0 100 Z" fill="currentColor" className="text-rose-300" />
                  </svg>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 opacity-20 transform rotate-90">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path d="M 0 0 L 100 0 L 0 100 Z" fill="currentColor" className="text-pink-300" />
                  </svg>
                </div>
                <div className="absolute bottom-0 left-0 w-24 h-24 opacity-20 transform -rotate-90">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path d="M 0 0 L 100 0 L 0 100 Z" fill="currentColor" className="text-pink-300" />
                  </svg>
                </div>
                <div className="absolute bottom-0 right-0 w-24 h-24 opacity-20 transform rotate-180">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path d="M 0 0 L 100 0 L 0 100 Z" fill="currentColor" className="text-rose-300" />
                  </svg>
                </div>

                {/* Animated Page Content */}
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentPage}
                    initial={{ 
                      rotateY: flipDirection === 'forward' ? 90 : -90,
                      opacity: 0,
                      scale: 0.8
                    }}
                    animate={{ 
                      rotateY: 0,
                      opacity: 1,
                      scale: 1
                    }}
                    exit={{ 
                      rotateY: flipDirection === 'forward' ? -90 : 90,
                      opacity: 0,
                      scale: 0.8
                    }}
                    transition={{ 
                      duration: 0.6,
                      ease: [0.4, 0, 0.2, 1]
                    }}
                    className="relative p-8 md:p-12 min-h-[500px] md:min-h-[600px] flex flex-col"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    {/* Page Background Pattern */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${page.color} opacity-40`}></div>
                    
                    {/* Decorative tape pieces */}
                    <div className="absolute top-4 left-8 w-20 h-8 bg-yellow-100/60 transform -rotate-12 shadow-sm"></div>
                    <div className="absolute top-4 right-8 w-20 h-8 bg-yellow-100/60 transform rotate-12 shadow-sm"></div>

                    {/* Content */}
                    <div className="relative z-10 flex flex-col items-center text-center flex-1">
                      
                      {/* Decorations Top */}
                      <motion.div 
                        className="flex gap-4 mb-6 text-4xl md:text-5xl"
                        initial={{ y: -20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.3 }}
                      >
                        {page.decorations.map((emoji, index) => (
                          <motion.span
                            key={index}
                            animate={{ 
                              rotate: [0, 10, -10, 0],
                              y: [0, -5, 0]
                            }}
                            transition={{ 
                              duration: 2,
                              repeat: Infinity,
                              delay: index * 0.2
                            }}
                          >
                            {emoji}
                          </motion.span>
                        ))}
                      </motion.div>

                      {/* Title */}
                      <motion.h3 
                        className={`font-playfair text-3xl md:text-4xl lg:text-5xl ${page.textColor} mb-3`}
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.4 }}
                      >
                        {page.title}
                      </motion.h3>

                      {/* Date */}
                      <motion.p 
                        className="font-poppins text-rose-600/60 italic mb-8 text-sm md:text-base"
                        style={{ fontWeight: 300 }}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.5 }}
                      >
                        {page.date}
                      </motion.p>

                      {/* Memory Card */}
                      <motion.div
                        className="relative max-w-2xl w-full"
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: 0.6 }}
                      >
                        {/* Polaroid-style photo frame effect */}
                        <div className="bg-white p-6 md:p-8 rounded-2xl shadow-xl transform rotate-1 hover:rotate-0 transition-transform duration-300">
                          <div className="bg-gradient-to-br from-rose-50 to-pink-50 p-6 md:p-8 rounded-xl border-2 border-rose-100">
                            <p 
                              className={`font-poppins ${page.textColor} leading-relaxed text-base md:text-lg text-center`}
                              style={{ fontWeight: 400 }}
                            >
                              {page.memory}
                            </p>
                          </div>
                          
                          {/* Handwritten-style note */}
                          <div className="mt-4 text-right">
                            <motion.div
                              className="inline-block"
                              animate={{ rotate: [-2, 2, -2] }}
                              transition={{ duration: 3, repeat: Infinity }}
                            >
                              <Heart className="w-6 h-6 text-rose-400 inline" fill="currentColor" />
                            </motion.div>
                          </div>
                        </div>
                      </motion.div>

                      {/* Page number at bottom */}
                      <motion.div 
                        className="mt-auto pt-8"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.7 }}
                      >
                        <p className="font-poppins text-rose-400/50 text-sm italic" style={{ fontWeight: 300 }}>
                          - Page {currentPage + 1} -
                        </p>
                      </motion.div>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="relative z-50 flex justify-between items-center mt-8 gap-4">
              <button
                onClick={prevPage}
                disabled={currentPage === 0}
                className={`relative z-50 flex items-center gap-2 px-6 py-3 rounded-full font-poppins transition-all duration-300 ${
                  currentPage === 0
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-pink-400 to-rose-400 text-white hover:shadow-xl hover:scale-105'
                }`}
                style={{ fontWeight: 600 }}
              >
                <ChevronLeft className="w-5 h-5" />
                <span className="hidden sm:inline">Previous</span>
              </button>

              <div className="flex gap-2">
                {scrapbookPages.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setFlipDirection(index > currentPage ? 'forward' : 'backward');
                      setCurrentPage(index);
                    }}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentPage
                        ? 'bg-rose-400 scale-125'
                        : 'bg-rose-200 hover:bg-rose-300'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={nextPage}
                disabled={currentPage === totalPages - 1}
                className={`relative z-50 flex items-center gap-2 px-6 py-3 rounded-full font-poppins transition-all duration-300 ${
                  currentPage === totalPages - 1
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-rose-400 to-pink-400 text-white hover:shadow-xl hover:scale-105'
                }`}
                style={{ fontWeight: 600 }}
              >
                <span className="hidden sm:inline">Next</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Instructions */}
            <motion.div
              className="text-center mt-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              <p className="font-poppins text-rose-600/70 text-sm" style={{ fontWeight: 300 }}>
                💡 Click the arrows or dots to flip through the pages
              </p>
            </motion.div>
          </div>

          {/* Extra padding for navigation */}
          <div className="h-32"></div>
        </motion.div>
      </div>
    </section>
  );
};