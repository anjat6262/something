import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { Check, X, RotateCcw } from 'lucide-react';

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const questions: QuizQuestion[] = [
  {
    question: "What is Gracie Abrams' debut studio album called?",
    options: ["Good Riddance", "Minor", "This Is What It Feels Like", "The Secret of Us"],
    correctIndex: 0,
    explanation: "\"Good Riddance\" was released in February 2023 and became her first full-length studio album!"
  },
  {
    question: "Which song features the lyrics 'I know it won't work'?",
    options: ["Difficult", "I know it won't work", "21", "Full machine"],
    correctIndex: 1,
    explanation: "\"I know it won't work\" is one of her most popular songs from the Good Riddance album!"
  },
  {
    question: "Gracie Abrams is the daughter of which famous director?",
    options: ["Steven Spielberg", "J.J. Abrams", "Christopher Nolan", "Quentin Tarantino"],
    correctIndex: 1,
    explanation: "Her father is J.J. Abrams, the acclaimed director and producer known for Star Wars and Star Trek!"
  },
  {
    question: "What year did Gracie Abrams release her first EP 'minor'?",
    options: ["2019", "2020", "2021", "2022"],
    correctIndex: 1,
    explanation: "\"minor\" was released in July 2020, marking her debut EP and introducing her intimate songwriting style!"
  },
  {
    question: "Which Taylor Swift song does Gracie Abrams collaborate on?",
    options: ["Anti-Hero", "Karma", "us. (from The Vault)", "Lavender Haze"],
    correctIndex: 2,
    explanation: "Gracie co-wrote and is featured on \"us.\" from Taylor Swift's 1989 (Taylor's Version) - From The Vault!"
  },
  {
    question: "What is the name of Gracie's 2023 deluxe album?",
    options: ["Good Riddance (Deluxe)", "The Secret of Us", "Good Riddance (Said Too Much Edition)", "This Is What It Feels Like"],
    correctIndex: 2,
    explanation: "She released \"Good Riddance (Said Too Much Edition)\" which included additional tracks!"
  },
  {
    question: "Which song starts with 'Tough, I'm so tough'?",
    options: ["Tough love", "Amelie", "I should hate you", "Best"],
    correctIndex: 2,
    explanation: "\"I should hate you\" features these memorable opening lyrics from the Good Riddance album!"
  },
  {
    question: "Gracie opened for which artist on tour in 2023?",
    options: ["Olivia Rodrigo", "Taylor Swift", "Billie Eilish", "Lorde"],
    correctIndex: 1,
    explanation: "Gracie was the opening act for Taylor Swift's The Eras Tour in 2023, performing for massive crowds!"
  }
];

export const FactQuiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [isQuizComplete, setIsQuizComplete] = useState(false);

  const handleAnswer = (index: number) => {
    setSelectedAnswer(index);
    setShowResult(true);
    
    if (index === questions[currentQuestion].correctIndex) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setIsQuizComplete(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setIsQuizComplete(false);
  };

  if (isQuizComplete) {
    const percentage = (score / questions.length) * 100;
    return (
      <motion.div
        className="text-center space-y-6"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div className="bg-gradient-to-br from-rose-100 to-pink-100 rounded-3xl p-8 shadow-xl">
          <motion.div
            className="text-6xl mb-4"
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 0.5, repeat: 3 }}
          >
            {percentage >= 80 ? '🏆' : percentage >= 60 ? '🌟' : '💕'}
          </motion.div>
          <h3 className="font-playfair text-3xl text-rose-900 mb-4">
            Quiz Complete!
          </h3>
          <p className="font-poppins text-2xl text-rose-700 mb-2" style={{ fontWeight: 600 }}>
            Score: {score}/{questions.length}
          </p>
          <p className="font-poppins text-rose-600/80 mb-6" style={{ fontWeight: 300 }}>
            {percentage >= 80 
              ? "You know her so well! That's beautiful! 💕" 
              : percentage >= 60 
              ? "Pretty good! You're learning more about her every day! ✨"
              : "Every question wrong is a chance to know her better! 🌸"}
          </p>
          <button
            onClick={resetQuiz}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-rose-400 to-pink-400 text-white rounded-full font-poppins hover:shadow-lg transition-all duration-300"
            style={{ fontWeight: 500 }}
          >
            <RotateCcw className="w-5 h-5" />
            Try Again
          </button>
        </div>
      </motion.div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h3 className="font-playfair text-2xl md:text-3xl text-rose-900 mb-2">
          Who Knows Gracie Abrams Better? 🎵
        </h3>
        <p className="font-poppins text-rose-700/70 text-sm" style={{ fontWeight: 300 }}>
          You or Me? Let's find out! • Question {currentQuestion + 1} of {questions.length}
        </p>
      </div>

      <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-6 md:p-8 shadow-xl border border-rose-100/50">
        <h4 className="font-poppins text-lg md:text-xl text-rose-900 mb-6 text-center" style={{ fontWeight: 500 }}>
          {question.question}
        </h4>

        <div className="space-y-3">
          {question.options.map((option, index) => {
            const isCorrect = index === question.correctIndex;
            const isSelected = index === selectedAnswer;
            
            return (
              <motion.button
                key={index}
                onClick={() => !showResult && handleAnswer(index)}
                disabled={showResult}
                className={`w-full p-4 rounded-2xl font-poppins text-left transition-all duration-300 ${
                  showResult
                    ? isCorrect
                      ? 'bg-green-100 border-2 border-green-400 text-green-900'
                      : isSelected
                      ? 'bg-red-100 border-2 border-red-400 text-red-900'
                      : 'bg-gray-100 text-gray-500'
                    : 'bg-rose-50 hover:bg-rose-100 border-2 border-rose-200 hover:border-rose-300 text-rose-900'
                }`}
                whileHover={!showResult ? { scale: 1.02, x: 5 } : {}}
                whileTap={!showResult ? { scale: 0.98 } : {}}
                style={{ fontWeight: 400 }}
              >
                <div className="flex items-center justify-between">
                  <span>{option}</span>
                  {showResult && (
                    <AnimatePresence>
                      {isCorrect && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          exit={{ scale: 0 }}
                        >
                          <Check className="w-6 h-6 text-green-600" />
                        </motion.div>
                      )}
                      {isSelected && !isCorrect && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          exit={{ scale: 0 }}
                        >
                          <X className="w-6 h-6 text-red-600" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>

        <AnimatePresence>
          {showResult && (
            <motion.div
              className="mt-6 p-4 bg-pink-50 rounded-2xl border border-pink-200"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <p className="font-poppins text-rose-800 text-sm leading-relaxed" style={{ fontWeight: 300 }}>
                💡 {question.explanation}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {showResult && (
        <motion.button
          onClick={nextQuestion}
          className="w-full px-6 py-3 bg-gradient-to-r from-rose-400 to-pink-400 text-white rounded-full font-poppins hover:shadow-lg transition-all duration-300"
          style={{ fontWeight: 500 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {currentQuestion < questions.length - 1 ? 'Next Question' : 'See Results'}
        </motion.button>
      )}
    </div>
  );
};