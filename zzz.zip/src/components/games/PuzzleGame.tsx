import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Sparkles } from 'lucide-react';

interface PuzzleGameProps {
  imageUrl: string;
}

export const PuzzleGame = ({ imageUrl }: PuzzleGameProps) => {
  const [pieces, setPieces] = useState<number[]>([]);
  const [isComplete, setIsComplete] = useState(false);
  const [moves, setMoves] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const gridSize = 3; // 3x3 puzzle
  const totalPieces = gridSize * gridSize;

  useEffect(() => {
    // Shuffle puzzle pieces
    const shuffled = Array.from({ length: totalPieces }, (_, i) => i).sort(() => Math.random() - 0.5);
    setPieces(shuffled);
  }, []);

  const swapPieces = (index: number) => {
    const newPieces = [...pieces];
    const emptyIndex = pieces.indexOf(totalPieces - 1); // Last piece is empty
    
    // Check if clicked piece is adjacent to empty space
    const clickedRow = Math.floor(index / gridSize);
    const clickedCol = index % gridSize;
    const emptyRow = Math.floor(emptyIndex / gridSize);
    const emptyCol = emptyIndex % gridSize;
    
    const isAdjacent = 
      (Math.abs(clickedRow - emptyRow) === 1 && clickedCol === emptyCol) ||
      (Math.abs(clickedCol - emptyCol) === 1 && clickedRow === emptyRow);
    
    if (isAdjacent) {
      [newPieces[index], newPieces[emptyIndex]] = [newPieces[emptyIndex], newPieces[index]];
      setPieces(newPieces);
      setMoves(moves + 1);
      
      // Check if puzzle is complete
      const isSolved = newPieces.every((piece, idx) => piece === idx);
      if (isSolved) {
        setIsComplete(true);
      }
    }
  };

  const resetPuzzle = () => {
    const shuffled = Array.from({ length: totalPieces }, (_, i) => i).sort(() => Math.random() - 0.5);
    setPieces(shuffled);
    setIsComplete(false);
    setMoves(0);
    setShowHint(false);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="font-playfair text-2xl md:text-3xl text-rose-900 mb-2">
          Puzzle Her Smile 🧩
        </h3>
        <p className="font-poppins text-rose-700/70 text-sm" style={{ fontWeight: 300 }}>
          Put the pieces together! Moves: {moves}
        </p>
      </div>

      <div className="max-w-md mx-auto">
        <div className="grid grid-cols-3 gap-1 bg-white/50 p-2 rounded-2xl shadow-xl relative">
          {/* Hint overlay - shows complete image with low opacity */}
          <AnimatePresence>
            {showHint && !isComplete && (
              <motion.div
                className="absolute inset-2 rounded-xl overflow-hidden pointer-events-none z-10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="relative w-full h-full">
                  <ImageWithFallback
                    src={imageUrl}
                    alt="Hint"
                    className="w-full h-full object-cover opacity-40"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-pink-500/20 to-rose-500/20" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {pieces.map((pieceIndex, index) => {
            const row = Math.floor(pieceIndex / gridSize);
            const col = pieceIndex % gridSize;
            const isEmpty = pieceIndex === totalPieces - 1;

            return (
              <motion.div
                key={index}
                className={`aspect-square relative overflow-hidden rounded-lg ${
                  isEmpty ? 'bg-rose-100/30' : 'cursor-pointer'
                }`}
                onClick={() => !isEmpty && !isComplete && swapPieces(index)}
                whileHover={!isEmpty && !isComplete ? { scale: 1.05 } : {}}
                whileTap={!isEmpty && !isComplete ? { scale: 0.95 } : {}}
                layout
              >
                {!isEmpty && (
                  <div
                    className="w-full h-full"
                    style={{
                      backgroundImage: `url(${imageUrl})`,
                      backgroundSize: '300%',
                      backgroundPosition: `${col * 50}% ${row * 50}%`,
                    }}
                  />
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Hint Button */}
      {!isComplete && (
        <div className="flex justify-center gap-3">
          <motion.button
            onClick={() => setShowHint(!showHint)}
            className={`px-6 py-3 rounded-full font-poppins transition-all duration-300 ${
              showHint
                ? 'bg-rose-400 text-white shadow-lg'
                : 'bg-white/70 text-rose-700 border-2 border-rose-200 hover:border-rose-300'
            }`}
            style={{ fontWeight: 500 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {showHint ? '👁️ Hiding Hint' : '💡 Show Hint'}
          </motion.button>
          
          <motion.button
            onClick={resetPuzzle}
            className="px-6 py-3 bg-white/70 text-rose-700 border-2 border-rose-200 hover:border-rose-300 rounded-full font-poppins transition-all duration-300"
            style={{ fontWeight: 500 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            🔄 Reset
          </motion.button>
        </div>
      )}

      <AnimatePresence>
        {isComplete && (
          <motion.div
            className="text-center space-y-4"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 0.5, repeat: 3 }}
            >
              <Sparkles className="w-12 h-12 text-pink-400 mx-auto" />
            </motion.div>
            <p className="font-playfair text-xl text-rose-700">
              Perfect! You completed it in {moves} moves! 💕
            </p>
            <button
              onClick={resetPuzzle}
              className="px-6 py-3 bg-gradient-to-r from-rose-400 to-pink-400 text-white rounded-full font-poppins hover:shadow-lg transition-all duration-300"
              style={{ fontWeight: 500 }}
            >
              Play Again
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};