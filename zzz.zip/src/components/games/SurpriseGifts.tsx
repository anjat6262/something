import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { Gift, Heart, Sparkles, Star, Music, Smile } from 'lucide-react';

interface GiftBox {
  id: number;
  message: string;
  icon: typeof Heart;
  color: string;
  emoji: string;
}

const gifts: GiftBox[] = [
  {
    id: 1,
    message: "You make ordinary moments feel special just by being you. Never forget how much light you bring! ✨",
    icon: Sparkles,
    color: "from-pink-400 to-rose-400",
    emoji: "✨"
  },
  {
    id: 2,
    message: "Your laugh is one of my favorite sounds in the world. It's genuine and contagious! 😊",
    icon: Smile,
    color: "from-rose-400 to-pink-500",
    emoji: "😊"
  },
  {
    id: 3,
    message: "Thank you for being someone I can talk to about anything. Your presence is a gift. 💕",
    icon: Heart,
    color: "from-pink-500 to-rose-500",
    emoji: "💕"
  },
  {
    id: 4,
    message: "You're beautiful—not just on the outside, but in the way you care for people around you. 🌸",
    icon: Star,
    color: "from-rose-500 to-pink-400",
    emoji: "🌸"
  },
  {
    id: 5,
    message: "Every Gracie Abrams song feels more meaningful when I think about you listening to it. 🎵",
    icon: Music,
    color: "from-pink-400 to-rose-500",
    emoji: "🎵"
  },
  {
    id: 6,
    message: "You deserve all the happiness in the world—today and every day. Happy Birthday! 🎂",
    icon: Gift,
    color: "from-rose-400 to-pink-400",
    emoji: "🎂"
  }
];

export const SurpriseGifts = () => {
  const [openedGifts, setOpenedGifts] = useState<number[]>([]);
  const [selectedGift, setSelectedGift] = useState<GiftBox | null>(null);

  const openGift = (gift: GiftBox) => {
    if (!openedGifts.includes(gift.id)) {
      setOpenedGifts([...openedGifts, gift.id]);
    }
    setSelectedGift(gift);
  };

  const closeMessage = () => {
    setSelectedGift(null);
  };

  const resetGifts = () => {
    setOpenedGifts([]);
    setSelectedGift(null);
  };

  const allOpened = openedGifts.length === gifts.length;

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h3 className="font-playfair text-2xl md:text-3xl text-rose-900 mb-2">
          Surprise Gifts For You! 🎁
        </h3>
        <p className="font-poppins text-rose-700/70 text-sm mb-4" style={{ fontWeight: 300 }}>
          Click each gift to reveal a special message
        </p>
        <p className="font-poppins text-rose-600 text-sm" style={{ fontWeight: 500 }}>
          Opened: {openedGifts.length}/{gifts.length}
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
        {gifts.map((gift) => {
          const isOpened = openedGifts.includes(gift.id);
          const Icon = gift.icon;

          return (
            <motion.div
              key={gift.id}
              className="relative"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: gift.id * 0.1 }}
            >
              <motion.button
                onClick={() => openGift(gift)}
                className={`w-full aspect-square rounded-3xl shadow-xl border-2 flex items-center justify-center relative overflow-hidden transition-all duration-300 ${
                  isOpened
                    ? 'bg-gradient-to-br border-rose-300'
                    : 'bg-white border-rose-200 hover:border-rose-300'
                }`}
                whileHover={{ scale: 1.05, rotate: isOpened ? 0 : 5 }}
                whileTap={{ scale: 0.95 }}
                animate={
                  !isOpened
                    ? { y: [0, -8, 0] }
                    : {}
                }
                transition={
                  !isOpened
                    ? { duration: 2, repeat: Infinity, delay: gift.id * 0.2 }
                    : {}
                }
              >
                {isOpened ? (
                  <motion.div
                    className={`bg-gradient-to-br ${gift.color} w-full h-full flex items-center justify-center`}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 200 }}
                  >
                    <Icon className="w-12 h-12 md:w-16 md:h-16 text-white" />
                  </motion.div>
                ) : (
                  <motion.div
                    animate={{ rotate: [0, -5, 5, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity, delay: gift.id * 0.3 }}
                  >
                    <Gift className="w-12 h-12 md:w-16 md:h-16 text-rose-400" />
                  </motion.div>
                )}

                {/* Sparkle effect when opened */}
                {isOpened && (
                  <motion.div
                    className="absolute top-2 right-2"
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Sparkles className="w-6 h-6 text-yellow-300" />
                  </motion.div>
                )}
              </motion.button>
            </motion.div>
          );
        })}
      </div>

      {/* Message Popup */}
      <AnimatePresence>
        {selectedGift && (
          <motion.div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeMessage}
          >
            <motion.div
              className="bg-white rounded-3xl p-8 md:p-12 max-w-md w-full shadow-2xl relative"
              initial={{ scale: 0.8, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 50 }}
              onClick={(e) => e.stopPropagation()}
            >
              <motion.div
                className="text-6xl mb-6 text-center"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 0.5, repeat: 2 }}
              >
                {selectedGift.emoji}
              </motion.div>

              <p className="font-poppins text-rose-800 text-center leading-relaxed text-base md:text-lg mb-8" style={{ fontWeight: 400 }}>
                {selectedGift.message}
              </p>

              <button
                onClick={closeMessage}
                className="w-full px-6 py-3 bg-gradient-to-r from-rose-400 to-pink-400 text-white rounded-full font-poppins hover:shadow-lg transition-all duration-300"
                style={{ fontWeight: 500 }}
              >
                Close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* All Opened Celebration */}
      <AnimatePresence>
        {allOpened && !selectedGift && (
          <motion.div
            className="bg-gradient-to-br from-rose-100 to-pink-100 rounded-3xl p-8 text-center shadow-xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <motion.div
              className="text-5xl mb-4"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 0.5, repeat: 3 }}
            >
              🎉
            </motion.div>
            <h4 className="font-playfair text-2xl text-rose-900 mb-3">
              All Gifts Opened!
            </h4>
            <p className="font-poppins text-rose-700 mb-6" style={{ fontWeight: 300 }}>
              Hope these messages made you smile! 💕
            </p>
            <button
              onClick={resetGifts}
              className="inline-flex items-center gap-2 px-6 py-3 bg-white text-rose-600 rounded-full font-poppins hover:shadow-lg transition-all duration-300 border border-rose-200"
              style={{ fontWeight: 500 }}
            >
              Reset Gifts
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
